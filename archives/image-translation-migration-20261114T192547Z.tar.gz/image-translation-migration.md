# One-time image-note translation migration

## Purpose and scope

This temporary screen in `python main.py --app` lets you select Polish
translations using the normal Diki editor, then writes them onto existing Anki
notes. It includes **every** note of `Basic [reverse+audio+image]` across all decks,
including notes that already have `pl_translation`. Saving replaces that field.

The initial queue is a snapshot, ordered by note ID. The collection had 380 notes
when this was designed, but there is no hardcoded count. Notes added after the
snapshot are not silently appended. Existing translations never imply completion;
only the explicit completion history in the JSON file does.

Each note needs `en_word` and a local image reference before starting. Audio may
be empty. The only Anki content mutation is:

```python
updateNoteFields(note={"id": original_note_id, "fields": {"pl_translation": html}})
```

The workflow does not create notes/cards, change note types or decks, download
audio, change flags or alter card scheduling. The assistant-review extension
adds/removes only the explicit `AI_PL_FLAWED` tag as described below. English text, image and audio
values are checked again after saving. AnkiWeb synchronization uses the main
app's normal immediate/rate-limited synchronization coordinator.

## Start and work in batches

1. Open the intended Anki profile with AnkiConnect enabled.
2. Start or restart the app to load the new backend routes:

   ```bash
   python main.py --app
   ```

3. On the home screen, find **Polish translations for image notes** and choose
   **Start migration**. This creates the JSON snapshot once. The home entry only
   reads progress; it does not initialize the queue or fetch Diki pages.
4. The screen displays the original English word, image, current Polish
   translation and Diki meanings. Diki uses the existing cache-first resource
   provider, including its offline mode and interactive cooldown handling.
5. Select meanings, edit individual values, optionally select a `<br>` between
   senses, or add a custom translation. The same `TranslationEditor` component
   serves this screen and the normal add/review workspace. The preview and save
   use `FactoryService.translation_html`: text is HTML-escaped, comma-separated
   by default and separated with `<br>` where selected. This does not establish
   a new general `pl_translation` data contract.
6. **Save translation & next** writes the selected translation, verifies the
   result and records completion. A nonempty selection is required. The old
   translation is shown for reference, not automatically selected or merged.
   **⌘S (Command+S)** performs the same action, including while editing translation
   text. It saves the latest draft first, and is inactive while busy or without a
   selected translation. Holding the keys does not repeatedly advance the queue.
7. **Skip for now** saves the draft and moves the note to the end of the pending
   queue. It is not counted as completed. With one pending note, it remains the
   current note.
8. **Save draft & exit** flushes the draft and returns home. For the end of a
   batch, use the normal **Sync & stop** button on the home screen to flush any
   pending AnkiWeb synchronization and stop the server.
9. Later, run the app again and choose **Resume migration**. Completed notes stay
   completed; the pending queue, edited meanings and selections are restored.

Drafts autosave after 550 ms of inactivity, including text still being edited.
Wait for **Saved locally** or use **Save draft & exit** before leaving. Closing a
browser/process abruptly can lose edits that have not reached the server yet;
the last successfully persisted draft remains available. Draft saving does not
modify Anki.

The dictionary lookup text is independent of the original English field. Trying
another spelling or a Diki suggestion never changes the note ID or English text.
Lookups run automatically for a new, untouched note. A saved draft is restored
without refetching/replacing its selections. **Look up** intentionally replaces
the current meaning groups with fresh dictionary results. If lookup fails, you
can retry, use a custom translation, ask Gemini for help (if configured), or skip.
Gemini answers are reference text; you enter the chosen translation in the editor.

## Assistant vision processing and human review

The coding assistant inspects the images directly. This path makes **no external
AI API calls**; the old optional Gemini button in the original manual screen is
independent. Diki HTTP requests still supply/cache dictionary HTML as usual.

The assistant first prepares a result for each image: preferably one Diki
translation, maximum two, or an unresolved result. Preparation and import do not
write translations or mark notes completed. Candidate IDs are internal checkbox
identifiers; the UI shows the actual Polish text.

On the home screen:

- **Review AI selections**: shows each proposed result, the full note (English,
  images, original/current Polish translation, optional audio and raw field
  values), an image description, explanation, and **all Diki alternatives used
  for that choice**, with the chosen ones highlighted.
- **Accept & next**, also **⌘S**: durably queues the decision and advances to the
  prefetched next note. The worker writes the translation to the same note and
  records acceptance only after verification succeeds.
- **Mark flawed & next**: records your optional feedback and adds the Anki note
  tag `AI_PL_FLAWED`. It leaves the translation unchanged and the note pending.
- **Correct manually now**: opens the shared existing translation editor on the
  current pending note. You can choose other meanings, refresh Diki or enter a
  custom translation. **Save correction & next** / **⌘S** queues the correction.
- **Fix flawed / unresolved**: opens that manual editor for rejected results and
  results the assistant could not confidently resolve. Drafts autosave and resume
  between batches. Successful correction removes `AI_PL_FLAWED` and completes
  the note. Unresolved results do not add the flawed tag until you mark them.
- **Accepted AI history**: lets you inspect accepted/corrected notes with their
  original AI candidates and explanation. Marking one flawed reopens it as
  pending without changing its current translation.

Use the batch selector to scope a queue and the note selector to navigate.
Switching queues/notes or exiting flushes pending correction drafts. A failed
save can be retried or returned to review as described below. Selecting a different dictionary
spelling never changes the target note ID or the immutable AI alternatives.

### Fast navigation and background saves

The review screen preloads the next **two** full note payloads and decodes their
images while you inspect the current note. Images use bounded, in-memory blob
URLs so they are reused despite the Anki media route's `no-store` response. The
cache retains at most six recent/lookahead notes and releases blob URLs on
eviction or exit. Audio remains on-demand.

Accept, manual correction and flawed decisions use a separate durable queue.
Clicking a decision or pressing ⌘S freezes the current note ID, profile, selected
draft/feedback, expected translation and displayed-image checksums. The server
persists this request without calling Anki; the UI can immediately show the
prefetched next note. A single worker performs the queued Anki operations in
order. The progress counter only changes after a verified local save; the
separate **N saves pending in background** indicator shows outstanding work.

- Queued/running notes are temporarily omitted from the selectable review list,
  but are not marked completed or accepted in the progress database.
- Failed jobs remain unevaluated when the Anki write did not succeed. They appear
  in a failed-save list instead of interrupting the next review.
- **Retry failed saves** retries the same recorded decisions. **Review again**
  cancels a failed request (not the note) and reloads fresh fields/candidates for
  a new decision. This is useful when an external edit makes the old request stale.
- Refreshing/closing the browser does not lose server-acknowledged jobs. The app
  continues processing them. A stopped/restarted server resumes queued/running
  jobs from disk. A normal shutdown drains the queue and flushes pending sync.
- A lost enqueue response is reconciled by its stable job ID. If a process fails
  after Anki changes but before the job receipt is stored, the existing field
  journal verifies the outcome before completing/retrying it; a confirmed save
  is not applied a second time.
- Per-note decision tokens replace global-revision checks for this path, so saving
  note A does not invalidate preloaded note B. Another decision on the same note,
  a changed translation, or changed displayed image is still rejected.
- A completed job includes its `completedRevision`. If a newer save response
  arrives before a fresh queue snapshot, the UI suppresses completed notes from
  older source queues until progress catches up. Accepted history remains
  available. Note payloads are checked against queue membership/status before
  display; polling repairs a clean selection removed by a background completion.
  An unsaved manual correction is retained for explicit reconciliation.
- AnkiWeb synchronization is coalesced after the local queue drains, outside HTTP
  requests and progress-file locks. A sync failure does not undo a verified local
  save. Normal app shutdown flushes dirty state after review workers finish.

The original synchronous APIs remain available for the original manual workflow.
No running save is cancelled by changing filters, switching review queues, or
returning home. Unsaved correction edits are still flushed when explicitly exiting.

Queue artifacts, alongside the original progress database:

```text
data/migrations/image-review-jobs.json
data/migrations/image-review-jobs.lock
data/migrations/image-review-jobs.worker.lock
```

The jobs JSON has `schemaVersion: 1` and a `jobs` dictionary keyed by stable job
ID. Each record contains the immutable request, word, timestamps, status
(`queued`, `running`, `done`, `failed`, `cancelled`) and optional error. The queue
has its own atomic replacement and lock, so enqueue/status operations do not wait
on the main progress lock while Anki is saving. The worker lock prevents two
server processes from applying jobs concurrently. Invalid queue JSON is reported,
never silently reset.

`completedRevision` is optional for older receipts; existing queue files do not
need to be reset or rewritten when updating the application.

Main progress items may additionally contain `lastReviewJobId`; an in-progress
translation journal may contain `reviewJobId`. A flawed-tag intent uses
`pendingReviewJobId` until the tag is confirmed. Preserve both JSON files together
when backing up or restoring queued work.

The `ai` field on an item stores `batchId`, `status`, `snapshotFields`, `groups`,
image filenames/content digests, `inputHash`, preparation/processing timestamps,
the assistant's `selection`, review feedback and timestamps. Status meanings:

| State | Meaning |
| --- | --- |
| No `ai` record, note pending | Awaiting assistant processing |
| `prepared` | Inputs exported, no assistant result imported yet |
| `proposed` | Assistant selection ready for human acceptance |
| `unresolved` | Assistant requests a manual decision |
| `flawed` | Human rejected it; pending correction and tagged in Anki |
| `accepted` | Human accepted the proposal and it was saved |
| `corrected` | Human saved a manual correction |

The pending/completed lists still represent actual saved completion. A proposal
does not move a note to completed. Existing manually completed notes need no AI
record. If a human finishes a prepared note before result import, the old
preparation is retained under `cancelledAIPreparation` and cannot overwrite the
human result.

The exact candidate list is retained for review. Import checks the prepared
input fingerprint, note fields and image bytes; acceptance also detects a changed
image, including replacement under the same filename. Tag intentions use
`tagPending` so failed tag writes are retried without losing review progress.
The translation journal's optional `completionStatus` preserves accepted versus
corrected state during interrupted-save recovery.

### Pilot and separate worker

The first pilot is `pilot-001`: the assistant directly inspected 20 diverse
images, producing 19 proposals and one unresolved result (`at`). One picture
(`bark`) depicts two different meanings, so that result deliberately selects
two translations. All other pilot results select one.

Review the pilot before asking a fresh worker to process the remaining notes.
Worker commands and the exact handoff brief are in
[image-translation-ai-worker.md](image-translation-ai-worker.md).

Local artifact layout:

```text
data/migrations/ai-batches/pilot-001/
  manifest.json       # note IDs, image paths, exact candidates, input hashes
  results.json        # assistant-authored selections and explanations
  <note-id>-0.jpg     # actual Anki image bytes for direct inspection
```

Both files and per-item `ai` state are resumable. These files are gitignored with
the rest of `data/`. Archive them with progress when removing the workflow.

## JSON progress database

Default location, relative to the project root:

```text
data/migrations/image-translations.json
data/migrations/image-translations.lock
```

This is independent of SQLite add sessions, `ANKI_FACTORY_DB_PATH`, the local word
index and Diki caches. `data/` is already gitignored. The lock file contains no
progress and serializes threads/processes using the existing `file_lock` helper.
JSON writes use a temporary file in the same directory, flush/fsync and atomic
replacement. The application does not reset malformed JSON automatically.

The persisted shape is:

```json
{
  "schemaVersion": 1,
  "noteType": "Basic [reverse+audio+image]",
  "profileName": "Your profile",
  "createdAt": "ISO timestamp",
  "updatedAt": "ISO timestamp",
  "revision": 12,
  "items": {
    "123": {
      "noteId": 123,
      "word": "example",
      "originalFields": {
        "en_word": "example",
        "audio_en": "[sound:example.mp3]",
        "pl_translation": "old translation",
        "image": "<img src=\"example.png\">"
      },
      "savedTranslation": "przykład",
      "completedAt": "ISO timestamp"
    }
  },
  "pending": [],
  "completed": [123],
  "drafts": {},
  "transaction": null
}
```

- `items` retains every original note/word and its original field values.
- `pending` is the ordered list of note IDs still to process.
- `completed` is the ordered completion history. Each completed item also has
  `savedTranslation` and `completedAt`.
- `drafts` is keyed by note ID. A draft has `lookupWord`, meaning `groups`
  (`original`, `value`, `selected`, optional `isBreak`), `suggestions`, `lookedUp`.
  Skipped-note drafts remain here; completed-note drafts are removed.
- `revision` rejects stale writes from another tab and late lookup responses.
- `transaction` journals an in-progress Anki write: `noteId`, `before`, `after`
  and the three `preserved` fields. It is cleared after verification.

Completion is local to this snapshot. Do not delete or replace the JSON file
between batches. Doing so loses completion history and a new start will include
all notes again, even those already translated. Keep a copy of the JSON when
archiving the project or moving machines; it references the named Anki profile
and the original note IDs. Stop the server before manually editing/restoring it.

## Interrupted saves and conflicts

The journal is persisted **before** sending `updateNoteFields`. On reopening or
reloading, the workflow compares the live note against that journal:

- Translation equals `after`, and the other three fields match: record completion
  and synchronize, without sending another field update.
- Translation equals `before`, and the other three fields match: leave the note
  pending, clear the journal and allow retry.
- Translation equals neither value, another field changed, the note disappeared
  or its type changed: show a conflict and preserve the journal for inspection.

If a save errors or its HTTP response is lost, choose **Reload current note**.
The JSON determines whether it actually completed. If an existing translation
changed outside this screen, reload refreshes the displayed translation before
you explicitly overwrite it. Unsaved local selections are retained when the
same note remains current. A different active Anki profile is rejected.

For a journal conflict, stop the server and copy the JSON before investigating.
Inspect `transaction` and that note in Anki. To retry the intended operation,
restore the journal's `before` translation and `preserved` fields on the note,
then reopen. To recognize the intended operation as completed, the note must
match `after` and `preserved`. If the newer external edits should be retained,
resolve the conflict deliberately rather than deleting the whole progress file.
Original fields in `items` are reference history, not an automatic rollback.

## Implementation manifest

Temporary files (delete when removing this feature):

| File | Purpose |
| --- | --- |
| `backend/image_translation_migration.py` | Migration state, journal, isolated routes, lookup, preview, image reads and translation-only saving |
| `backend/migration_review_jobs.py` | Durable background decisions, retries, per-note checks and worker lifecycle |
| `frontend/src/ImageTranslationMigration.tsx` | Home entry, workflow screen, serialized autosave/save/skip/exit |
| `frontend/src/AITranslationReview.tsx` | Full-note AI review, acceptance, rejection, history and manual correction |
| `frontend/src/MigrationMedia.tsx` | Migration-specific image/audio previews |
| `frontend/src/reviewPrefetch.ts` | Bounded note/decoded-image prefetch cache |
| `frontend/src/image-translation-migration.css` | Styles imported by the temporary screen |
| `tests/test_image_translation_migration.py` | Mock-backed persistence, mutation, recovery, concurrency, media and HTTP tests |
| `tests/test_image_translation_ai.py` | AI snapshot/import/review/tag/recovery/batch tests |
| `tests/test_migration_review_jobs.py` | Delayed/failed saves, recovery, tokens, immutable drafts and queue tests |
| `tests/browser_review_navigation.py` | Optional Chrome regression for completed-job/stale-queue navigation races |
| `tools/image_translation_ai.py` | Prepare/export assistant inputs and import results without an AI API |
| `image-translation-ai-worker.md` | Optional removable worker instructions |

Shared changes to retain:

- `frontend/src/TranslationEditor.tsx`: extracted selector/editor used by the
  main workspace. Retain its import and usage in `App.tsx`.
- Existing Diki, AnkiConnect and translation formatter helpers are reused; the
  SQLite session schema was not changed. `FactoryService.mark_sync_pending`
  records deferred synchronization, and the app's final lifespan flush happens
  after the router worker drains. These small shared sync improvements may remain
  after removing the migration. The helper may be removed if it has no callers.

Integration points to remove:

1. `backend/app.py`: the `migration_router` import and
   `app.include_router(migration_router(service))` line.
2. `frontend/src/App.tsx`: the `ImageTranslationMigration` /
   `ImageTranslationMigrationEntry` import, `imageMigrationOpen` state, the
   `if (imageMigrationOpen)` rendering block, and the
   `<ImageTranslationMigrationEntry ... />` home-screen element.
   Also remove the `AITranslationReview` / `AIReviewKind` import, `aiReviewKind`
   state and `if (aiReviewKind)` rendering block.
3. `README.md`: the one-time migration section linking this guide.

`plan.md` and `research.md` have clearly titled image-translation sections;
retain them as history or remove those sections only. Their offline-Diki content
predates this work. This guide may also be retained as history.

## Safe removal after completion

1. Wait for **All queued saves finished** and resolve all failed saves before
   removing queue files/code. Check **remaining = 0** and **completed = total**, and inspect several saved
   notes in Anki. Use **Save draft & exit**, then **Sync & stop**.
2. Archive `data/migrations/image-translations.json` and
   `data/migrations/image-review-jobs.json` (if present). They contain original
   translations, replacements, completion timestamps and background-save receipts.
3. Remove the integration points above, then delete the temporary files listed
   in the manifest (including AI-review/tool files).
   Keep `TranslationEditor.tsx` and its usage in the main workspace.
4. Rebuild the frontend to remove the screen from the served bundle:

   ```bash
   npm --prefix frontend run build
   python -m unittest tests.test_target_selection tests.test_review_stateless tests.test_session_storage tests.test_sync_rate_limit
   git diff --check
   ```

5. Restart the app. Verify the normal add/review workspace still opens and the
   migration home entry is gone.
6. After archiving, the migration JSON and `.lock` can be removed with the server
   stopped. Do not remove the rest of `data/`: it contains normal sessions and
   Diki caches. A stray `image-translations-*.tmp` from a terminated write may
   also be removed after the server is stopped; it is not the active database.

   After preserving completed work, remove the jobs JSON, its `.lock` and
   `.worker.lock`, and any leftover `image-review-jobs-*.tmp`, with the server
   stopped. Do not delete a queue with pending jobs as a way to stop processing:
   it contains decisions the UI has already acknowledged.

   Archive/remove `data/migrations/ai-batches/` as well. If you remove the workflow
   with unresolved notes, `AI_PL_FLAWED` tags remain in Anki until deliberately
   corrected or removed; deleting application code does not delete Anki tags.

Removing the workflow **does not undo translations in Anki**. Reverting field
content is a separate deliberate operation; this feature provides no bulk undo.

## Verification

Focused backend verification (all Anki/Diki calls are mocked):

```bash
python -m unittest tests.test_image_translation_migration tests.test_image_translation_ai tests.test_migration_review_jobs tests.test_target_selection tests.test_review_stateless tests.test_session_storage tests.test_sync_rate_limit tests.test_audio_sync tests.test_diki_meanings tests.test_diki_regression
npm --prefix frontend run build
```

The migration tests cover inclusion of already-translated notes, optional audio,
exact note-ID targeting, only `pl_translation` in mutation payloads, preservation
of other fields/tags/card references, HTML escaping, resume/skip, stale requests,
two concurrent saves, malformed JSON, failed atomic replacement, failed and
interrupted saves, completion, profile/type/word conflicts and image endpoints.

An isolated Chrome smoke check used the built frontend, the actual migration
router, fake Anki/Diki and a temporary JSON file. It exercised the shared editor
in the normal workspace, image display, editing/custom meanings/line breaks,
draft-and-exit, a new browser context resuming without refetching, overwrite,
skip, final completion and desktop/mobile layout. No real notes were changed.

The initial manual migration passed 45 focused tests. The assistant-review
extension adds tests for proposal-only import, immutable Diki alternatives,
arbitrary pending-note acceptance, image-byte changes, unresolved choices,
flawed tagging and retries, correction drafts, non-head interrupted saves,
accepted-history reopening and resumable worker exports. The extended Chrome
check covers AI acceptance, rejection without a translation write, manual
draft/exit/resume/correction, tag removal, accepted-history reopening and recovery
after a lost acceptance HTTP response.

Current verification: **60 Python tests passed**; frontend typecheck/build passed;
Chrome desktop/mobile checks passed with zero JavaScript errors; diff whitespace
checks passed. Live read-only checks confirmed that all 20 pilot notes' fields
remain unchanged, 12 prior manual completions remain, and real English MP3 media
can be read. The pilot has 19 review proposals, one unresolved note and 348 notes
awaiting the post-pilot worker at pilot delivery.

### Post-pilot processing checkpoint

Following user approval and pilot feedback, all 348 untouched notes were processed
with one fresh agent per batch, sequentially: 34 batches of 10 and one of eight.
All results were validated/imported: **325 proposals, 23 unresolved**. The two
flawed pilot notes remain for later, so **Fix flawed / unresolved** initially
contains 25 notes. All 348 processed notes' live fields were verified unchanged.
There are no unprocessed or prepared-only notes left. Batch manifests/results
remain in `data/migrations/ai-batches/remaining-001` through `remaining-035`.

### Fast-review verification checkpoint

73 focused/regression Python tests passed, including the new background queue
tests; frontend typecheck/production build passed. An isolated Chrome test held
the first fake Anki write blocked while two consecutive ⌘S decisions advanced to
the already-decoded next images. It verified no duplicate image downloads,
refresh/new context with durable pending saves, a failed write remaining
unevaluated while later reviews continue, successful retry, a captured unconfirmed
manual edit, and reconciliation of a lost enqueue response. Zero JavaScript
errors occurred. All write testing used fake Anki data and temporary files.

### Completed-note navigation regression

A controlled browser test reproduced the garden-hose/watering-can bug: polling
restored a still-running note in an old queue, then a newer save acknowledgment
reported that note done and made it selectable again. The old UI displayed it
as accepted in the proposal queue with no Accept button. The fixed UI keeps
advancing to a pending proposal and self-heals stale displayed selections.

Optional regression command (requires the `playwright` Python package and
installed Chrome, in addition to the built frontend):

```bash
npm --prefix frontend run build
python -m tests.browser_review_navigation
```

The test uses the real built frontend with locally mocked backend/media routes;
it never accesses Anki or progress files. It covers the exact completion race,
delayed prefetched images, accepted-history navigation, stale cached metadata,
automatic reconciliation, and preservation of an unsaved correction. The async
worker browser smoke also passes after this fix, preserving non-blocking saves,
refresh recovery and failed-save retry.
