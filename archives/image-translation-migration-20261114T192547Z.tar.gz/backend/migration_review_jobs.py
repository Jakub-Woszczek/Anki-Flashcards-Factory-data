"""Durable sequential saves for the temporary image-note review workflow."""

from contextlib import contextmanager
from copy import deepcopy
import json
import os
import tempfile
import threading
from typing import Literal

from pydantic import BaseModel, Field

from backend.image_translation_migration import (
    AIFlawedRequest, AIManualRequest, AIReviewRequest, MigrationDraft, now,
)
from backend.services import ServiceError
from external_APIs.diki_resources import file_lock


class ReviewDecision(BaseModel):
    id: str = Field(min_length=1, max_length=100, pattern=r"^[A-Za-z0-9_-]+$")
    noteId: int
    profileName: str
    noteToken: str
    action: Literal["accept", "manual", "flawed"]
    expectedTranslation: str
    expectedImage: str | None = None
    imageDigests: list[str] | None = None
    draft: MigrationDraft | None = None
    reason: str = "Marked flawed during human review"


class JobReference(BaseModel):
    id: str


class ReviewJobQueue:
    def __init__(self, migration):
        self.migration = migration
        self.path = migration.path.with_name("image-review-jobs.json")
        self._wake = threading.Event()
        self._stopping = threading.Event()
        self._thread = None

    @contextmanager
    def _locked(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with file_lock(self.path.with_suffix(".lock")):
            yield

    def _read(self):
        if not self.path.exists():
            return {"schemaVersion": 1, "jobs": {}}
        try:
            state = json.loads(self.path.read_text(encoding="utf-8"))
            if state["schemaVersion"] != 1 or not isinstance(state["jobs"], dict):
                raise ValueError("Invalid queue")
            for key, job in state["jobs"].items():
                request = ReviewDecision.model_validate(job["request"])
                if request.id != key or job["status"] not in {"queued", "running", "done", "failed", "cancelled"}:
                    raise ValueError("Invalid job")
            return state
        except (ValueError, OSError, KeyError, TypeError) as error:
            raise ServiceError("The review-save queue is invalid; it has not been reset.", 409) from error

    def _write(self, state):
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.path.parent,
                                             prefix="image-review-jobs-", suffix=".tmp", delete=False) as handle:
                temporary = handle.name
                json.dump(state, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
        finally:
            if temporary and os.path.exists(temporary):
                os.unlink(temporary)

    @staticmethod
    def _view(state):
        jobs = [{"id": key, "noteId": job["request"]["noteId"], "word": job["word"],
                 "action": job["request"]["action"], "status": job["status"], "error": job.get("error"),
                 "completedRevision": job.get("completedRevision")}
                for key, job in state["jobs"].items()]
        return {"jobs": jobs, "pending": sum(j["status"] in {"queued", "running"} for j in jobs),
                "failed": sum(j["status"] == "failed" for j in jobs)}

    def snapshot(self):
        with self._locked():
            return self._view(self._read())

    def submit(self, request: ReviewDecision):
        # No Anki/network call and no long-held progress lock on this fast path.
        progress = self.migration._read()
        if progress is None or progress["profileName"] != request.profileName:
            raise ServiceError("This review belongs to another migration/profile", 409)
        payload = request.model_dump()
        with self._locked():
            state = self._read()
            existing = state["jobs"].get(request.id)
            if existing:
                if existing["request"] != payload:
                    raise ServiceError("This job ID already belongs to another decision", 409)
            else:
                item = progress["items"].get(str(request.noteId))
                if not item or not item.get("ai", {}).get("selection") or request.noteToken != self.migration.note_token(progress, request.noteId):
                    raise ServiceError("This note changed; reload before submitting the decision", 409)
                if request.action != "flawed" and request.noteId not in progress["pending"]:
                    raise ServiceError("This note is no longer pending", 409)
                if request.action == "accept" and item["ai"]["status"] != "proposed":
                    raise ServiceError("This note requires manual correction", 409)
                if request.action == "manual" and (request.draft is None or not self.migration.preview(request.draft)["translationHtml"]):
                    raise ServiceError("Select or enter a translation before saving")
                active = next((job for job in state["jobs"].values() if job["request"]["noteId"] == request.noteId
                               and job["status"] in {"queued", "running", "failed"}), None)
                if active:
                    raise ServiceError("This note already has a queued/failed save. Reload or retry it.", 409)
                state["jobs"][request.id] = {"request": payload, "word": item["word"], "status": "queued",
                                             "createdAt": now(), "updatedAt": now(), "error": None}
                self._write(state)
            result = self._view(state)
        self._wake.set()
        return result

    def retry(self):
        with self._locked():
            state = self._read()
            for job in state["jobs"].values():
                if job["status"] == "failed":
                    job.update(status="queued", error=None, updatedAt=now())
            self._write(state)
            result = self._view(state)
        self._wake.set()
        return result

    def dismiss(self, request: JobReference):
        with self._locked():
            state = self._read()
            job = state["jobs"].get(request.id)
            if job is None or job["status"] != "failed":
                raise ServiceError("Only a failed save can be returned for review", 409)
            job.update(status="cancelled", updatedAt=now())
            self._write(state)
            return self._view(state)

    def _perform(self, job):
        request = ReviewDecision.model_validate(job["request"])
        migration = self.migration
        with migration._locked():
            state = migration._read()
            if state is None or state["profileName"] != request.profileName:
                raise ServiceError("The queued review belongs to another profile", 409)
            # The field update/completion may have succeeded before a process or
            # HTTP failure. Do not apply that decision twice.
            if state["items"].get(str(request.noteId), {}).get("lastReviewJobId") == request.id:
                migration.factory.mark_sync_pending()
                return
            state = migration._state()
            if state["items"].get(str(request.noteId), {}).get("lastReviewJobId") == request.id:
                migration.factory.mark_sync_pending()
                return
            revision = state["revision"]
            if request.expectedImage is not None or request.imageDigests is not None:
                fields = migration._note(request.noteId)
                if request.expectedImage is not None and fields["image"] != request.expectedImage:
                    raise ServiceError("The image changed after it was displayed. Review this note again.", 409)
                if request.imageDigests is not None and [image["digest"] for image in migration._image_records(fields)] != request.imageDigests:
                    raise ServiceError("The image file changed after it was displayed. Review this note again.", 409)
        common = {"noteId": request.noteId, "revision": revision, "noteToken": request.noteToken,
                  "reviewJobId": request.id, "deferSync": True}
        if request.action == "accept":
            migration.ai_accept(AIReviewRequest(**common, expectedTranslation=request.expectedTranslation))
        elif request.action == "manual":
            migration.ai_manual(AIManualRequest(**common, expectedTranslation=request.expectedTranslation, draft=request.draft))
        else:
            migration.ai_flawed(AIFlawedRequest(**common, reason=request.reason))

    def process_one(self):
        """Caller owns worker.lock. Also usable synchronously with fakes in tests."""
        with self._locked():
            state = self._read()
            entry = next(((key, job) for key, job in state["jobs"].items() if job["status"] in {"queued", "running"}), None)
            if entry is None:
                return False
            key, job = entry
            job.update(status="running", updatedAt=now())
            self._write(state)
            copied = deepcopy(job)
        error = None
        try:
            self._perform(copied)
        except Exception as failure:
            # Reconcile uncertain outcomes before reporting a failure. Recovery
            # only completes a note when its exact intended fields are verified.
            try:
                with self.migration._locked():
                    progress = self.migration._read()
                    transaction = progress.get("transaction") if progress else None
                    if transaction and transaction.get("reviewJobId") == key:
                        self.migration._profile(progress)
                        self.migration._recover(progress)
                    item = progress["items"].get(str(copied["request"]["noteId"]), {}) if progress else {}
                    succeeded = item.get("lastReviewJobId") == key
                if succeeded:
                    self.migration.factory.mark_sync_pending()
                else:
                    error = str(failure)
            except Exception:
                error = str(failure)
        completed_revision = self.migration._read()["revision"] if error is None else None
        with self._locked():
            state = self._read()
            state["jobs"][key].update(status="failed" if error else "done", error=error, updatedAt=now(),
                                       completedRevision=completed_revision)
            self._write(state)
        return True

    def _run(self):
        while True:
            try:
                if self.path.exists():
                    with file_lock(self.path.with_suffix(".worker.lock"), blocking=False):
                        worked = False
                        while self.process_one():
                            worked = True
                        if worked:
                            # Coalesce AnkiWeb synchronization after the local
                            # queue drains, outside HTTP and progress-file locks.
                            self.migration.factory.flush_sync()
                if self._stopping.is_set():
                    return
                self._wake.wait(0.5)
                self._wake.clear()
            except BlockingIOError:
                if self._stopping.wait(0.2):
                    return
            except Exception:
                # Preserve the on-disk queue on filesystem/unavailability errors.
                # The UI can still show/retry failed jobs; restart resumes running.
                if self._stopping.wait(0.5):
                    return

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stopping.clear()
        self._thread = threading.Thread(target=self._run, name="image-review-saves", daemon=True)
        self._thread.start()

    def stop(self):
        self._stopping.set()
        self._wake.set()
        if self._thread:
            self._thread.join()
