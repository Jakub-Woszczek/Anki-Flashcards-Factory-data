"""Temporary, note-ID-bound translation migration. See image-translation-migration.md."""

import base64
from copy import deepcopy
from contextlib import contextmanager
from contextlib import asynccontextmanager
from datetime import UTC, datetime
import json
import hashlib
import os
from pathlib import Path
import re
import tempfile
from typing import Literal
from urllib.parse import unquote

from bs4 import BeautifulSoup
from fastapi import APIRouter
from fastapi.responses import Response
from pydantic import BaseModel, Field

from backend.services import ServiceError
from backend.settings import ROOT_DIR
from external_APIs.diki_resources import ResourceError, file_lock


NOTE_TYPE = "Basic [reverse+audio+image]"
FIELDS = ("en_word", "audio_en", "pl_translation", "image")
PROGRESS_PATH = ROOT_DIR / "data" / "migrations" / "image-translations.json"
FLAWED_TAG = "AI_PL_FLAWED"


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def now():
    return datetime.now(UTC).isoformat()


class TranslationChoice(BaseModel):
    original: str = ""
    value: str
    selected: bool = False
    isBreak: bool = False


class MigrationDraft(BaseModel):
    lookupWord: str
    groups: list[list[TranslationChoice]] = Field(default_factory=list)
    suggestions: list[str] = Field(default_factory=list)
    lookedUp: bool = False


class ItemRequest(BaseModel):
    noteId: int
    revision: int
    noteToken: str | None = None
    reviewJobId: str | None = None
    deferSync: bool = False


class DraftRequest(ItemRequest):
    draft: MigrationDraft


class LookupRequest(ItemRequest):
    word: str = Field(min_length=1, max_length=500)


class CommitRequest(DraftRequest):
    expectedTranslation: str


class AISelection(BaseModel):
    noteId: int
    inputHash: str
    selectedIds: list[str] = Field(default_factory=list, max_length=2)
    visualDescription: str = Field(min_length=1)
    reason: str = Field(min_length=1)
    needsReview: bool = False


class AIReviewRequest(ItemRequest):
    expectedTranslation: str


class AIFlawedRequest(ItemRequest):
    reason: str = "Marked flawed during human review"


class AIManualRequest(CommitRequest):
    pass


class ImageTranslationMigration:
    def __init__(self, factory, path: Path = PROGRESS_PATH):
        self.factory = factory
        self.path = path

    @contextmanager
    def _locked(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with file_lock(self.path.with_suffix(".lock")):
            yield

    def _read(self):
        if not self.path.exists():
            return None

        def require(condition):
            if not condition:
                raise ValueError("Invalid migration state")

        try:
            state = json.loads(self.path.read_text(encoding="utf-8"))
            require(state["schemaVersion"] == 1 and state["noteType"] == NOTE_TYPE)
            require(type(state["revision"]) is int and state["revision"] >= 0)
            require(isinstance(state["profileName"], str))
            items = state["items"]
            pending, completed = state["pending"], state["completed"]
            require(isinstance(items, dict) and isinstance(state["drafts"], dict))
            require(isinstance(pending, list) and isinstance(completed, list))
            require(all(type(note_id) is int for note_id in pending + completed))
            require(len(set(pending + completed)) == len(pending + completed))
            require({str(note_id) for note_id in pending + completed} == set(items))
            for key, item in items.items():
                require(item["noteId"] == int(key) and isinstance(item["word"], str))
                require(all(isinstance(item["originalFields"][field], str) for field in FIELDS))
                ai = item.get("ai")
                if ai:
                    require(ai["status"] in {"prepared", "proposed", "unresolved", "flawed", "accepted", "corrected"})
                    require(isinstance(ai["groups"], list) and isinstance(ai["snapshotFields"], dict))
                    require(all(isinstance(group, list) and all(isinstance(text, str) for text in group) for group in ai["groups"]))
                    require(isinstance(ai["inputHash"], str) and isinstance(ai["batchId"], str))
                    require(isinstance(ai["images"], list))
                    if ai.get("selection"):
                        selection = AISelection.model_validate(ai["selection"])
                        require(selection.noteId == item["noteId"] and selection.inputHash == ai["inputHash"])
            for key, draft in state["drafts"].items():
                require(int(key) in pending)
                MigrationDraft.model_validate(draft)
            transaction = state.get("transaction")
            if transaction:
                require(transaction["noteId"] in pending)
                require(isinstance(transaction["before"], str) and isinstance(transaction["after"], str))
                require(set(transaction["preserved"]) == set(FIELDS) - {"pl_translation"})
                require(all(isinstance(value, str) for value in transaction["preserved"].values()))
        except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
            raise ServiceError("Migration JSON is unreadable or invalid. Restore its backup; it was not reset.", 409) from error
        return state

    def _write(self, state):
        state["revision"] += 1
        state["updatedAt"] = now()
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.path.parent,
                                             prefix="image-translations-", suffix=".tmp", delete=False) as handle:
                temporary = Path(handle.name)
                json.dump(state, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
        finally:
            if temporary and temporary.exists():
                temporary.unlink()

    def _anki(self, action, **params):
        # AnkiConnect.last_error is shared across request threads; use this
        # response directly so an unrelated request cannot mask a failed write.
        import requests
        from external_APIs.ankiConnect import REQUEST_TIMEOUT_SECONDS

        try:
            response = requests.post(self.factory.anki.anki_URL,
                                     json={"action": action, "version": 6, "params": params},
                                     timeout=REQUEST_TIMEOUT_SECONDS)
            response.raise_for_status()
            result = response.json()
            if not isinstance(result, dict):
                raise ServiceError("Invalid AnkiConnect response", 503)
            if result.get("error") is not None:
                raise ServiceError(str(result["error"]), 503)
            if "result" not in result:
                raise ServiceError("Incomplete AnkiConnect response", 503)
            return result["result"]
        except (requests.RequestException, ValueError) as error:
            raise ServiceError(f"AnkiConnect migration request failed: {error}", 503) from error

    def _profile(self, state):
        if self._anki("getActiveProfile") != state["profileName"]:
            raise ServiceError("Open the Anki profile used to start this migration.", 409)

    def _note(self, note_id):
        notes = self._anki("notesInfo", notes=[note_id])
        if not notes or len(notes) != 1 or notes[0].get("noteId") != note_id:
            raise ServiceError(f"Migration note {note_id} no longer exists", 409)
        note = notes[0]
        if note.get("modelName") != NOTE_TYPE:
            raise ServiceError(f"Note {note_id} no longer uses {NOTE_TYPE}", 409)
        fields = {name: value["value"] for name, value in note.get("fields", {}).items()}
        if not all(isinstance(fields.get(field), str) for field in FIELDS):
            raise ServiceError("The migration note is missing a required field", 409)
        return fields

    def _complete(self, state, transaction):
        note_id = transaction["noteId"]
        state["items"][str(note_id)].update(savedTranslation=transaction["after"], completedAt=now())
        state["pending"].remove(note_id)
        state["completed"].append(note_id)
        state["drafts"].pop(str(note_id), None)
        if transaction.get("reviewJobId"):
            state["items"][str(note_id)]["lastReviewJobId"] = transaction["reviewJobId"]
        ai = state["items"][str(note_id)].get("ai")
        if ai and ai.get("selection"):
            ai.update(status=transaction.get("completionStatus", "corrected"), reviewedAt=now(), tagPending=True)
        elif ai:
            # A human can finish a note while a worker is still preparing it.
            # Preserve that preparation as history without exposing a fake result.
            state["items"][str(note_id)]["cancelledAIPreparation"] = state["items"][str(note_id)].pop("ai")
        state["transaction"] = None
        self._write(state)

    def _recover(self, state):
        transaction = state.get("transaction")
        if not transaction:
            return False
        fields = self._note(transaction["noteId"])
        if any(fields[name] != value for name, value in transaction["preserved"].items()):
            raise ServiceError("Interrupted save: other note fields changed. Resolve the note before continuing.", 409)
        if fields["pl_translation"] == transaction["after"]:
            self._complete(state, transaction)
            return True
        if fields["pl_translation"] == transaction["before"]:
            state["transaction"] = None
            self._write(state)
            return False
        raise ServiceError("Interrupted save conflicts with the current Anki translation. See the migration guide.", 409)

    def _state(self):
        state = self._read()
        if state is None:
            raise ServiceError("Start the image translation migration first", 404)
        self._profile(state)
        recovered = self._recover(state)
        tags_changed = self._reconcile_ai_tags(state)
        if recovered or tags_changed:
            # Recovery may be triggered by any endpoint, not just /current.
            self.factory._sync_after_mutation()
        return state

    def _current(self, state, request):
        if state["revision"] != request.revision or not state["pending"] or state["pending"][0] != request.noteId:
            raise ServiceError("Migration progress changed. Reload the current note before continuing.", 409)
        fields = self._note(request.noteId)
        if fields["en_word"] != state["items"][str(request.noteId)]["word"]:
            raise ServiceError("The English word changed after the migration snapshot. Resolve it before continuing.", 409)
        return fields

    def _summary(self, state):
        if state is None:
            return {"started": False, "noteType": NOTE_TYPE, "progressPath": str(self.path)}
        ai_counts = {"awaiting": 0, "prepared": 0, "proposed": 0, "unresolved": 0, "flawed": 0, "accepted": 0, "corrected": 0}
        for item in state["items"].values():
            if item.get("ai"):
                ai_counts[item["ai"]["status"]] += 1
            elif item["noteId"] in state["pending"]:
                ai_counts["awaiting"] += 1
        return {
            "started": True, "noteType": NOTE_TYPE, "progressPath": str(self.path),
            "profileName": state["profileName"], "total": len(state["items"]),
            "completed": len(state["completed"]), "remaining": len(state["pending"]),
            "revision": state["revision"], "updatedAt": state["updatedAt"],
            "aiCounts": ai_counts,
        }

    def status(self):
        return self._summary(self._read())

    def start(self):
        with self._locked():
            state = self._read()
            if state is None:
                profile = self._anki("getActiveProfile")
                ids = self._anki("findNotes", query="note:" + json.dumps(NOTE_TYPE))
                if not isinstance(profile, str) or not isinstance(ids, list):
                    raise ServiceError("Anki did not return a profile and note list", 503)
                items = {}
                for start in range(0, len(ids), 250):
                    batch = ids[start:start + 250]
                    notes = self._anki("notesInfo", notes=batch)
                    if len(notes) != len(batch) or {note.get("noteId") for note in notes} != set(batch):
                        raise ServiceError("Incomplete note snapshot; try starting again", 503)
                    for note in notes:
                        fields = {name: value["value"] for name, value in note.get("fields", {}).items()}
                        if note.get("modelName") != NOTE_TYPE or not all(isinstance(fields.get(f), str) for f in FIELDS):
                            raise ServiceError("A note changed during the snapshot; try again", 409)
                        if not fields["en_word"].strip() or not self._image_sources(fields["image"]):
                            raise ServiceError(f"Note {note['noteId']} needs English text and an image first", 409)
                        note_id = note["noteId"]
                        items[str(note_id)] = {"noteId": note_id, "word": fields["en_word"], "originalFields": fields}
                if not items:
                    raise ServiceError("No image notes found in the active Anki profile", 404)
                state = {"schemaVersion": 1, "noteType": NOTE_TYPE, "profileName": profile,
                         "createdAt": now(), "updatedAt": now(), "revision": 0,
                         "items": items, "pending": sorted(ids), "completed": [], "drafts": {}, "transaction": None}
                self._profile(state)
                self._write(state)
            else:
                self._profile(state)
        return self.current()

    def current(self):
        with self._locked():
            state = self._state()
            result = self._summary(state)
            result["current"] = None
            if state["pending"]:
                note_id = state["pending"][0]
                fields = self._note(note_id)
                item = state["items"][str(note_id)]
                if fields["en_word"] != item["word"]:
                    raise ServiceError("The current English word changed after the snapshot", 409)
                result["current"] = {
                    "noteId": note_id, "word": item["word"], "fields": fields,
                    "draft": state["drafts"].get(str(note_id), {
                        "lookupWord": item["word"], "groups": [], "suggestions": [], "lookedUp": False,
                    }),
                    "imageCount": len(self._image_sources(fields["image"])),
                }
        return result

    def draft(self, request: DraftRequest):
        with self._locked():
            state = self._state()
            self._current(state, request)
            state["drafts"][str(request.noteId)] = request.draft.model_dump()
            self._write(state)
            return self._summary(state)

    def lookup(self, request: LookupRequest):
        # Release the progress lock during slow dictionary requests, then reject
        # stale results rather than attaching them to a different queue item.
        with self._locked():
            state = self._state()
            self._current(state, request)
        word = " ".join(request.word.split()).lower()
        if not word:
            raise ServiceError("Enter a word to look up")
        try:
            translations, suggestions = self.factory.diki.lookup(word)
        except ResourceError as error:
            raise ServiceError(str(error), 503) from error
        with self._locked():
            state = self._state()
            self._current(state, request)
            draft = {"lookupWord": word, "groups": self.factory._translation_groups(translations),
                     "suggestions": suggestions, "lookedUp": True}
            state["drafts"][str(request.noteId)] = draft
            self._write(state)
            return {**self._summary(state), "draft": draft}

    def skip(self, request: DraftRequest):
        with self._locked():
            state = self._state()
            self._current(state, request)
            state["drafts"][str(request.noteId)] = request.draft.model_dump()
            state["pending"].append(state["pending"].pop(0))
            self._write(state)
        return self.current()

    def commit(self, request: CommitRequest):
        groups = self.factory._selected_translation_groups(request.draft.model_dump())
        translation = self.factory.translation_html(groups)
        if not translation:
            raise ServiceError("Select or enter at least one nonempty translation")
        with self._locked():
            state = self._state()
            fields = self._current(state, request)
            if fields["pl_translation"] != request.expectedTranslation:
                raise ServiceError("The translation changed in Anki. Reload this note before saving.", 409)
            state["drafts"][str(request.noteId)] = request.draft.model_dump()
            transaction = {
                "noteId": request.noteId, "before": fields["pl_translation"], "after": translation,
                "preserved": {field: fields[field] for field in FIELDS if field != "pl_translation"},
            }
            state["transaction"] = transaction
            self._write(state)
            self._anki("updateNoteFields", note={"id": request.noteId, "fields": {"pl_translation": translation}})
            if not self._recover(state):
                raise ServiceError("Anki did not retain the proposed translation; the note is still pending", 503)
            self._reconcile_ai_tags(state)
        sync = self.factory._sync_after_mutation()
        return {**self.current(), **sync, "savedNoteId": request.noteId}

    def preview(self, draft: MigrationDraft):
        groups = self.factory._selected_translation_groups(draft.model_dump())
        return {"translationHtml": self.factory.translation_html(groups)}

    def _reconcile_ai_tags(self, state):
        changed = False
        for item in state["items"].values():
            ai = item.get("ai", {})
            if ai.get("tagPending"):
                action = "addTags" if ai["status"] == "flawed" else "removeTags"
                self._anki(action, notes=[item["noteId"]], tags=FLAWED_TAG)
                ai["tagPending"] = False
                if ai.get("pendingReviewJobId"):
                    item["lastReviewJobId"] = ai.pop("pendingReviewJobId")
                self._write(state)
                changed = True
        return changed

    def note_token(self, state, note_id):
        item = state["items"].get(str(note_id), {})
        ai = item.get("ai", {})
        return fingerprint({"profile": state["profileName"], "noteId": note_id,
                            "status": ai.get("status"), "selection": ai.get("selection"),
                            "inputHash": ai.get("inputHash"), "reviewedAt": ai.get("reviewedAt"),
                            "completedAt": item.get("completedAt"), "pending": note_id in state["pending"]})

    def _ai_fields(self, state, note_id, revision=None, *, pending=True, note_token=None):
        if note_token is not None and note_token != self.note_token(state, note_id):
            raise ServiceError("This note was reviewed elsewhere. Reload before continuing.", 409)
        if note_token is None and revision is not None and revision != state["revision"]:
            raise ServiceError("Migration progress changed. Reload before continuing.", 409)
        if str(note_id) not in state["items"] or (pending and note_id not in state["pending"]):
            raise ServiceError("This note is not pending in the migration", 409)
        fields = self._note(note_id)
        if fields["en_word"] != state["items"][str(note_id)]["word"]:
            raise ServiceError("The English word changed after the snapshot", 409)
        return fields

    def _ai_read_state(self):
        # Atomic replacement makes this a consistent snapshot without waiting on
        # the progress lock while a background job talks to Anki. Legacy recovery
        # remains available; queued writes are recovered by their owning worker.
        state = self._read()
        if state is None:
            raise ServiceError("Start the migration first", 404)
        transaction = state.get("transaction")
        legacy_transaction = transaction and not transaction.get("reviewJobId")
        legacy_tags = any(item.get("ai", {}).get("tagPending") and not item.get("lastReviewJobId")
                          and not item.get("ai", {}).get("pendingReviewJobId") for item in state["items"].values())
        if legacy_transaction or legacy_tags:
            with self._locked():
                return self._state()
        return state

    def _after_review(self, request):
        if request.deferSync:
            self.factory.mark_sync_pending()
            return {"syncPending": True}
        return self.factory._sync_after_mutation()

    def _image_records(self, fields):
        records = []
        for source in self._image_sources(fields["image"]):
            encoded = self._anki("retrieveMediaFile", filename=source)
            if not isinstance(encoded, str):
                raise ServiceError(f"Anki image is missing: {source}", 409)
            content = base64.b64decode(encoded, validate=True)
            records.append({"filename": source, "digest": hashlib.sha256(content).hexdigest()})
        return records

    def prepare_ai(self, note_id, batch_id):
        """Prepare inputs only; reasoning is performed by this assistant/worker."""
        with self._locked():
            state = self._state()
            fields = self._ai_fields(state, note_id)
            existing = state["items"][str(note_id)].get("ai")
            if existing:
                if existing["batchId"] != batch_id:
                    raise ServiceError("This note already belongs to another AI batch", 409)
                return deepcopy(existing)
        error = None
        try:
            groups, _ = self.factory.diki.lookup(fields["en_word"])
        except ResourceError as failure:
            groups, error = [], str(failure)
        images = self._image_records(fields)
        if not images:
            raise ServiceError("The note needs an image before AI processing", 409)
        ai = {"status": "prepared", "batchId": batch_id, "snapshotFields": fields,
              "groups": groups, "images": images, "preparationError": error, "preparedAt": now()}
        ai["inputHash"] = fingerprint({key: ai[key] for key in ("snapshotFields", "groups", "images")})
        with self._locked():
            state = self._state()
            if self._ai_fields(state, note_id) != fields:
                raise ServiceError("The note changed while preparing AI inputs", 409)
            if state["items"][str(note_id)].get("ai"):
                raise ServiceError("Another worker prepared this note; resume the batch", 409)
            state["items"][str(note_id)]["ai"] = ai
            self._write(state)
        return deepcopy(ai)

    @staticmethod
    def _selected_ai_groups(ai, selection):
        candidates = {f"{gi}:{ti}": text for gi, group in enumerate(ai["groups"]) for ti, text in enumerate(group)}
        ids = selection.selectedIds
        if len(set(ids)) != len(ids) or any(key not in candidates for key in ids):
            raise ServiceError("AI selection contains an unknown or repeated Diki choice", 409)
        if not ids and not selection.needsReview:
            raise ServiceError("An empty AI selection must be flagged for manual review", 409)
        return [[candidates[key] for key in ids]] if ids else []

    def import_ai(self, selections):
        """Idempotent import of assistant-authored results; never updates Anki."""
        with self._locked():
            state = self._state()
            changed, seen = False, set()
            for selection in selections:
                if selection.noteId in seen:
                    raise ServiceError("Repeated note in results", 409)
                seen.add(selection.noteId)
                ai = state["items"].get(str(selection.noteId), {}).get("ai")
                if not ai or ai["inputHash"] != selection.inputHash:
                    raise ServiceError("AI results do not match the prepared inputs", 409)
                self._selected_ai_groups(ai, selection)
                if ai["status"] != "prepared":
                    if ai.get("selection") == selection.model_dump():
                        continue
                    raise ServiceError("This AI result was already imported or reviewed", 409)
                fields = self._ai_fields(state, selection.noteId)
                if fields != ai["snapshotFields"] or self._image_records(fields) != ai["images"]:
                    raise ServiceError("The note or image changed since AI preparation", 409)
                ai.update(selection=selection.model_dump(),
                          status="unresolved" if selection.needsReview else "proposed", processedAt=now())
                changed = True
            if changed:
                self._write(state)
            return self._summary(state)

    def ai_queue(self, kind: Literal["review", "manual", "accepted"] = "review", batchId: str | None = None):
        state = self._ai_read_state()
        statuses = {"review": {"proposed"}, "manual": {"unresolved", "flawed"}, "accepted": {"accepted", "corrected"}}[kind]
        items = [{"noteId": item["noteId"], "word": item["word"], "status": item["ai"]["status"], "batchId": item["ai"]["batchId"]}
                 for item in state["items"].values() if item.get("ai", {}).get("status") in statuses
                 and (batchId is None or item["ai"]["batchId"] == batchId)]
        return {**self._summary(state), "items": items}

    def ai_note(self, note_id: int):
        state = self._ai_read_state()
        self._profile(state)
        fields = self._ai_fields(state, note_id, pending=False)
        ai = state["items"][str(note_id)].get("ai")
        if not ai or not ai.get("selection"):
            raise ServiceError("No AI result is available for this note", 404)
        selected = self._selected_ai_groups(ai, AISelection.model_validate(ai["selection"]))
        draft = self.factory._translation_groups(ai["groups"])
        ids = set(ai["selection"]["selectedIds"])
        for gi, group in enumerate(draft):
            for ti, choice in enumerate(group):
                choice["selected"] = f"{gi}:{ti}" in ids and not choice.get("isBreak")
        return {**self._summary(state), "noteId": note_id, "fields": fields, "ai": ai,
                "noteToken": self.note_token(state, note_id),
                "originalFields": state["items"][str(note_id)]["originalFields"],
                "proposalHtml": self.factory.translation_html(selected),
                "imageCount": len(self._image_sources(fields["image"])),
                "audioCount": len(self._audio_sources(fields["audio_en"])),
                "draft": state["drafts"].get(str(note_id), {"lookupWord": fields["en_word"], "groups": draft,
                                                         "suggestions": [], "lookedUp": True})}

    def ai_flawed(self, request: AIFlawedRequest):
        with self._locked():
            state = self._state()
            self._ai_fields(state, request.noteId, request.revision, pending=False, note_token=request.noteToken)
            ai = state["items"][str(request.noteId)].get("ai")
            if not ai or not ai.get("selection"):
                raise ServiceError("No AI result exists for this note", 409)
            if request.noteId in state["completed"]:
                state["completed"].remove(request.noteId)
                state["pending"].append(request.noteId)
            ai.update(status="flawed", reviewReason=request.reason, reviewedAt=now(), tagPending=True)
            if request.reviewJobId:
                ai["pendingReviewJobId"] = request.reviewJobId
            self._write(state)
            self._reconcile_ai_tags(state)
        return {**self.ai_note(request.noteId), **self._after_review(request)}

    def ai_accept(self, request: AIReviewRequest):
        with self._locked():
            state = self._state()
            fields = self._ai_fields(state, request.noteId, request.revision, note_token=request.noteToken)
            ai = state["items"][str(request.noteId)].get("ai")
            if not ai or ai["status"] != "proposed":
                raise ServiceError("This note needs manual correction before saving", 409)
            if fields["en_word"] != ai["snapshotFields"]["en_word"] or fields["image"] != ai["snapshotFields"]["image"] or self._image_records(fields) != ai["images"]:
                raise ServiceError("The image or word changed. Correct this note manually.", 409)
            translation = self.factory.translation_html(self._selected_ai_groups(ai, AISelection.model_validate(ai["selection"])))
            self._ai_save(state, request, fields, translation, "accepted")
        return {**self.status(), **self._after_review(request)}

    def _ai_save(self, state, request, fields, translation, completion):
        if not translation:
            raise ServiceError("Select at least one translation")
        if fields["pl_translation"] != request.expectedTranslation:
            raise ServiceError("The translation changed in Anki. Reload before saving.", 409)
        state["transaction"] = {"noteId": request.noteId, "before": fields["pl_translation"], "after": translation,
                                "preserved": {name: fields[name] for name in FIELDS if name != "pl_translation"},
                                "completionStatus": completion}
        if request.reviewJobId:
            state["transaction"]["reviewJobId"] = request.reviewJobId
        self._write(state)
        self._anki("updateNoteFields", note={"id": request.noteId, "fields": {"pl_translation": translation}})
        if not self._recover(state):
            raise ServiceError("Anki did not retain the translation; reload before retrying", 503)
        self._reconcile_ai_tags(state)

    def ai_draft(self, request: DraftRequest):
        with self._locked():
            state = self._state()
            self._ai_fields(state, request.noteId, request.revision, note_token=request.noteToken)
            state["drafts"][str(request.noteId)] = request.draft.model_dump()
            self._write(state)
            return {**self._summary(state), "noteToken": self.note_token(state, request.noteId)}

    def ai_manual(self, request: AIManualRequest):
        with self._locked():
            state = self._state()
            fields = self._ai_fields(state, request.noteId, request.revision, note_token=request.noteToken)
            if not state["items"][str(request.noteId)].get("ai"):
                raise ServiceError("This note has no AI review record", 409)
            state["drafts"][str(request.noteId)] = request.draft.model_dump()
            translation = self.factory.translation_html(self.factory._selected_translation_groups(request.draft.model_dump()))
            self._ai_save(state, request, fields, translation, "corrected")
        return {**self.status(), **self._after_review(request)}

    def ai_lookup(self, request: LookupRequest):
        with self._locked():
            state = self._state()
            self._ai_fields(state, request.noteId, request.revision, note_token=request.noteToken)
        word = " ".join(request.word.split()).lower()
        try:
            groups, suggestions = self.factory.diki.lookup(word)
        except ResourceError as error:
            raise ServiceError(str(error), 503) from error
        draft = MigrationDraft(lookupWord=word, groups=self.factory._translation_groups(groups), suggestions=suggestions, lookedUp=True)
        self.ai_draft(DraftRequest(noteId=request.noteId, revision=request.revision, noteToken=request.noteToken, draft=draft))
        return self.ai_note(request.noteId)

    @staticmethod
    def _audio_sources(value):
        return [source for source in re.findall(r"\[sound:([^\]]+)\]", value)
                if source and not any(char in source for char in ("/", "\\", "\0", ":"))]

    def audio(self, note_id: int, index: int):
        with self._locked():
            state = self._state()
            fields = self._ai_fields(state, note_id, pending=False)
            sources = self._audio_sources(fields["audio_en"])
            if index < 0 or index >= len(sources):
                raise ServiceError("No recording exists at that index", 404)
            source = sources[index]
            types = {".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".wav": "audio/wav", ".m4a": "audio/mp4"}
            if Path(source).suffix.lower() not in types:
                raise ServiceError("Unsupported recording format", 415)
            encoded = self._anki("retrieveMediaFile", filename=source)
            if not isinstance(encoded, str):
                raise ServiceError("Recording is missing in Anki", 404)
            return Response(base64.b64decode(encoded, validate=True), media_type=types[Path(source).suffix.lower()],
                            headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})

    @staticmethod
    def _image_sources(value):
        # Only filenames embedded in the target note may be retrieved. Never
        # render arbitrary stored note HTML or proxy a caller-supplied URL/path.
        sources = []
        for image in BeautifulSoup(value, "html.parser").find_all("img"):
            source = unquote(image.get("src", ""))
            if source and not any(char in source for char in ("/", "\\", "\0", ":")) and source not in {".", ".."}:
                sources.append(source)
        return sources

    def image(self, note_id: int, index: int):
        state = self._read()
        if state is None or str(note_id) not in state["items"]:
            raise ServiceError("Image note is not in this migration", 404)
        self._profile(state)
        sources = self._image_sources(self._note(note_id)["image"])
        if index < 0 or index >= len(sources):
            raise ServiceError("Image was not found on this note", 404)
        filename = sources[index]
        types = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
                 ".gif": "image/gif", ".webp": "image/webp", ".avif": "image/avif"}
        media_type = types.get(Path(filename).suffix.lower())
        if media_type is None:
            raise ServiceError("This image format is not supported by the migration preview", 415)
        encoded = self._anki("retrieveMediaFile", filename=filename)
        if not isinstance(encoded, str):
            raise ServiceError("Anki media file is missing", 404)
        try:
            content = base64.b64decode(encoded, validate=True)
        except ValueError as error:
            raise ServiceError("Anki returned invalid image data", 503) from error
        return Response(content, media_type=media_type,
                        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


def migration_router(factory):
    from backend.migration_review_jobs import ReviewJobQueue

    migration = ImageTranslationMigration(factory)
    jobs = ReviewJobQueue(migration)

    @asynccontextmanager
    async def lifespan(_app):
        jobs.start()
        try:
            yield
        finally:
            from starlette.concurrency import run_in_threadpool
            await run_in_threadpool(jobs.stop)

    router = APIRouter(prefix="/backend/image-translation-migration", lifespan=lifespan)
    router.add_api_route("/status", migration.status, methods=["GET"])
    router.add_api_route("/start", migration.start, methods=["POST"])
    router.add_api_route("/current", migration.current, methods=["GET"])
    router.add_api_route("/draft", migration.draft, methods=["PATCH"])
    router.add_api_route("/lookup", migration.lookup, methods=["POST"])
    router.add_api_route("/skip", migration.skip, methods=["POST"])
    router.add_api_route("/commit", migration.commit, methods=["POST"])
    router.add_api_route("/preview", migration.preview, methods=["POST"])
    router.add_api_route("/images/{note_id}/{index}", migration.image, methods=["GET"])
    router.add_api_route("/audio/{note_id}/{index}", migration.audio, methods=["GET"])
    router.add_api_route("/ai/queue", migration.ai_queue, methods=["GET"])
    router.add_api_route("/ai/notes/{note_id}", migration.ai_note, methods=["GET"])
    router.add_api_route("/ai/accept", migration.ai_accept, methods=["POST"])
    router.add_api_route("/ai/flawed", migration.ai_flawed, methods=["POST"])
    router.add_api_route("/ai/manual", migration.ai_manual, methods=["POST"])
    router.add_api_route("/ai/draft", migration.ai_draft, methods=["PATCH"])
    router.add_api_route("/ai/lookup", migration.ai_lookup, methods=["POST"])
    router.add_api_route("/ai/jobs", jobs.snapshot, methods=["GET"])
    router.add_api_route("/ai/jobs", jobs.submit, methods=["POST"], status_code=202)
    router.add_api_route("/ai/jobs/retry", jobs.retry, methods=["POST"])
    router.add_api_route("/ai/jobs/dismiss", jobs.dismiss, methods=["POST"])
    return router
