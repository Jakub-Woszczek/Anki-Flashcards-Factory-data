# Approved implementation plan: offline Diki

## Approved follow-up: temporary image-translation migration

### Approved fast-review extension

Navigation bugfix: agent investigation plus a controlled Chrome regression
reproduced an accepted note resurfacing from an older queue snapshot after a newer
save acknowledgment. Completed receipts now include their progress revision;
source-queue filtering, status/membership checks before adoption and poll-time
reconciliation prevent the stuck screen while preserving accepted history and
unsaved manual corrections. Existing progress/receipts are preserved. The exact
old-build regression failed as reported, then all four browser cases passed after
the fix, along with the async-save smoke, 50 focused tests and frontend build.

- [x] Persist sequential review decisions in an independent jobs JSON; only
  complete evaluations after verified local saves. Preserve retry/restart
  outcomes with stable job IDs and the existing field journal.
- [x] Use per-note decision tokens so unrelated queued saves do not invalidate
  prefetched notes. Check displayed images and freeze manual drafts at click time.
- [x] Prefetch the next two full notes and decoded image blobs, keep a bounded
  cache, advance after the fast enqueue acknowledgment, and show pending/failed
  counts with retry/return-to-review controls.
- [x] Finish final regression/browser checks and update removal documentation.

Fast-review verification: 73 focused/regression tests passed, TypeScript/Vite
production build passed, and an isolated Chrome check advanced two notes while
the first Anki save was deliberately blocked. It verified decoded blob reuse,
refresh with durable pending jobs, failed-save retry without evaluation, captured
unconfirmed manual text, lost enqueue acknowledgment recovery and zero JavaScript
errors. All writes used fake Anki and temporary progress/queue files.

### Assistant vision + human review extension (approved in conversation)

Use the coding assistant's image-reading tools, with a fresh worker after pilot
feedback. Do not add an external AI API to this path. Prefer one Diki choice,
maximum two. Prepare proposals first; write translations only on human acceptance.

- [x] Add durable per-note input snapshots, candidate/image fingerprints, AI
  result import, review/accept/flawed/manual states and tag reconciliation.
- [x] Add full-note review with images/audio, all original Diki alternatives,
  highlighted choices, explanations, accept/flawed/manual controls and history.
- [x] Add local batch preparation/import tool and directly inspect a varied
  20-note pilot, preserving the 12 manually completed notes.
- [x] Complete worker/removal documentation and final mocked/browser verification.

Pilot `pilot-001`: 19 proposals and one unresolved preposition (`at`). Stored in
`data/migrations/ai-batches/pilot-001/`; none of its translations have been written
to Anki at pilot delivery. After the user's pilot review, all 348 untouched notes
were processed by 35 fresh agents sequentially (34 batches of 10, one of eight):
325 proposals and 23 unresolved. Coverage/import validation passed, no prepared
or awaiting-AI notes remain, and all 348 live note fields were unchanged.
Explicit flawed tagging is the only added
non-translation mutation; correction removes `AI_PL_FLAWED`.

Extension verification: 60 focused/regression tests passed, TypeScript/Vite build
passed, and Chrome review/manual/history/mobile flows passed with no JavaScript
errors, including recovery after an acceptance HTTP response is deliberately
lost. Live read-only verification confirmed all 20 pilot notes still match their
prepared fields, the 12 manual completions remain, and a real Anki MP3 is readable.

Approved in conversation: include the whole image note type across decks,
overwrite existing translations on save, use resumable JSON state and provide
an exact removal guide. Keep the original offline-Diki plan below intact.

- [x] Add isolated migration router/service with atomic locked JSON state,
  note-bound lookup/image retrieval, translation-only save and recovery journal.
- [x] Extract shared translation editor and add temporary migration UI/home entry
  with autosaved drafts, explicit save/skip/exit, and completed/pending counts.
- [x] Document the workflow and removal manifest in
  `image-translation-migration.md`.
- [x] Verify mutation isolation, overwrite/resume/recovery/stale requests with
  mocks, run relevant regressions and frontend build, and inspect the diff.

The JSON snapshot records original fields and note IDs, pending/completed IDs,
per-note drafts, revisions and any in-progress write. Completion is never inferred
from a nonempty translation. Skips rotate the pending queue without completing an
item. Reuse the existing Diki cache, HTML formatter and synchronization behavior.
No note creation, type conversion, audio download, deck/flag edits or SQLite
schema changes are part of this feature. The AI-review extension adds only the
explicit flawed-tag behavior documented above. Removal instructions are the rollback
plan for code; removing code does not revert Anki field updates.

Verification: 45 focused/regression Python tests passed; frontend TypeScript/Vite
build passed; isolated Chrome smoke passed for the normal shared editor and
migration draft/resume/overwrite/skip/completion flow on desktop/mobile with no
JavaScript errors. All mutation checks used fake Anki data and temporary JSON.

Approved in conversation, including 20 seconds +/- 5 seconds of independently
sampled jitter after each completed request. Implementation is authorized.

## Tasks

- [x] Add `external_APIs/diki_resources.py`: atomic hashed HTML/audio storage,
  SQLite metadata, cache-first and strict offline modes, refresh, persisted retry
  state, one cross-process HTTP request at a time, persisted pacing and cooldown.
- [x] Route Diki HTML and audio through the provider. Retain pure parsers and the
  compatibility audio harness. Upload cached bytes directly to active Anki;
  preserve existing sound fields on failed updates. Surface lookup failures.
- [x] Add shared recursive word-list discovery (main file first) and resumable
  `tools/diki_prefetch.py`: 25 attempted words, 600-second budget, one job lock,
  persisted audio fallback progress, backoff and run summaries.
- [x] Add a launchd plist generator with absolute interpreter/project paths,
  login and 30-minute scheduling, plus install/uninstall instructions.
- [x] Add a disk-only coverage endpoint and home-screen panel showing per-list
  HTML/audio/exact-match readiness, exceptional states, last run and cooldown.
- [x] Add meaningful mocked offline, pacing, retries, resume, coverage and export
  tests; run targeted Python tests and frontend build; document operations.

## Decisions

Cache: `data/diki_cache/{index.sqlite3,html/,audio/}`; no automatic eviction.
Shared words download once. 404 suggestion pages count as HTML, not ready.
No-recording is terminal until explicit refresh; transient failures retry later.
Recognized blocks and HTTP 403/429 stop batches and impose at least six hours of
cooldown (or longer Retry-After). Cache hits never wait on the request lock.
The runtime budget may end before 25 words; missing audio variants resume on the
next run. Dashboard inspection never calls Diki or Anki.

## Verification and rollback

Verify zero-network cache hits, cache-only misses, 404 reuse, invalid/block
responses, persistent randomized pacing, corrupt files, budget interruption,
audio variant resume, list deduplication and cached export. Use fakes for Anki.
Run parser regressions and frontend typecheck/build. No live Anki mutation tests.

Rollback: unload the launch agent, revert feature files, retain the independent
cache directory for later reuse. No existing list/session migration is required.

## Verification results

- `python -m unittest` with the ten documented modules: 50 tests, 48 passed,
  two live HTTP tests skipped by default.
- Frontend `npm run build`: TypeScript and Vite production build passed.
- Generated launchd plist: `plutil -lint` passed.
- Real local coverage report: 1,045 unique main-list entries and 648 unique
  Fablehaven entries; report performed no network requests.
- `git diff --check`: passed.
- Installed the generated agent under `~/Library/LaunchAgents/` and loaded it.
  `launchctl list` confirms the agent and exit status 0. Its first live batch
  encountered a connection failure on `bind`, recorded a retry and cooldown,
  and exited normally. The initial cache was empty; later scheduled runs resumed
  successfully after Diki recovered (see the live verification below).

## Follow-up: live failure investigation

- [x] Compare the old request directly against the cache request in isolated
  temporary directories, using the original header from Git.
- [x] Trace the underlying exception; confirm HTTP 524 from normal requests with
  a longer diagnostic timeout for both `take` and `bind` (about 125 seconds).
- [x] Restore the original header; fix false block detection on normal
  Cloudflare-tagged dictionary HTML; retain detailed request failures.
- [x] Continue after isolated read timeouts/5xx errors, with a three-consecutive-
  failure circuit breaker; retain 20 +/- 5 second spacing and hard-block cooldown.
- [x] Regression checks: 55 tests, 53 passed and two live tests skipped.
- [x] Reloaded launchd and verified a real batch with the corrected code:
  three paced requests, three explicit ReadTimeout reports, circuit breaker,
  normal exit status 0. It remains enabled on the 30-minute schedule.
- [x] Live HTML/audio batches verified after Diki recovered: by November 9 the
  background downloader had cached 85 HTML pages and 70 MP3s, with 70 words fully
  ready offline. It subsequently recognized an anti-bot challenge and honored
  the configured cooldown. Browser experiments were removed; normal requests
  remain the only HTTP transport.
