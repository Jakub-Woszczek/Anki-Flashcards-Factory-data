"""Optional Chrome regression: python -m tests.browser_review_navigation.

Requires a built frontend, the optional playwright package and installed Chrome.
Every backend/media request is fulfilled locally; no Anki or progress file is used.
"""

import base64
from collections import Counter
from functools import partial
import html
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import threading
import time
from urllib.parse import parse_qs, urlsplit

from playwright.sync_api import expect, sync_playwright


BASE = "/backend/image-translation-migration"
DIST = Path(__file__).resolve().parent.parent / "frontend" / "dist"
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aK1sAAAAASUVORK5CYII=")


class Fixture:
    def __init__(self, scenario="completion-race"):
        self.scenario = scenario
        self.statuses = {1: "proposed", 2: "accepted" if scenario == "stale-metadata" else "proposed", 3: "proposed"}
        self.words = {1: "garden hose", 2: "watering can", 3: "wheelbarrow"}
        self.revision = 1
        self.jobs = []
        self.decisions = []
        self.queue_reads = 0
        self.note_reads = Counter()
        self.stale_poll_delivered = False
        self.delayed_images = []
        self.delayed_drafts = []
        self.external_complete = False

    def summary(self):
        return {"revision": self.revision, "aiCounts": {
            "proposed": sum(value == "proposed" for value in self.statuses.values()),
            "accepted": sum(value == "accepted" for value in self.statuses.values()),
            "flawed": 0, "unresolved": 0, "corrected": 0}}

    def jobs_view(self):
        return {"jobs": self.jobs, "pending": sum(job["status"] in {"queued", "running"} for job in self.jobs), "failed": 0}

    def note(self, note_id):
        status = self.statuses[note_id]
        fields = {"en_word": self.words[note_id], "image": '<img src="test.png">', "audio_en": "",
                  "pl_translation": "saved translation" if status == "accepted" else ""}
        return {**self.summary(), "noteId": note_id, "noteToken": f"token-{note_id}-{status}", "profileName": "Browser fixture",
                "fields": fields, "originalFields": {**fields, "pl_translation": ""}, "imageCount": 1, "audioCount": 0,
                "proposalHtml": "propozycja", "draft": {"lookupWord": self.words[note_id], "lookedUp": True,
                    "groups": [[{"original": "propozycja", "value": "propozycja", "selected": True}]], "suggestions": []},
                "ai": {"status": status, "batchId": "regression", "groups": [["propozycja", "alternatywa"]],
                       "selection": {"selectedIds": ["0:0"], "visualDescription": "Test image", "reason": "Test meaning", "needsReview": False}}}

    @staticmethod
    def reply(route, value):
        route.fulfill(status=200, content_type="application/json", body=json.dumps(value), headers={"Cache-Control": "no-store"})

    def route(self, route):
        request = route.request
        url = urlsplit(request.url)
        path = url.path
        if path == "/backend/status":
            return self.reply(route, {"ankiAvailable": True, "geminiConfigured": False})
        if path in {"/backend/sessions", "/backend/decks"}:
            return self.reply(route, [])
        if path == "/backend/review/inventory":
            return self.reply(route, {"tags": [], "flags": []})
        if path == "/backend/offline-coverage":
            return self.reply(route, {"lists": [], "offlineOnly": True, "cooldownUntil": 0, "pacingMultiplier": 1, "requestCounts": {}, "lastRun": None})
        if path == BASE + "/status":
            return self.reply(route, {**self.summary(), "started": True, "total": 3, "completed": 0, "remaining": 3})
        if path == BASE + "/ai/jobs":
            if request.method == "POST":
                decision = request.post_data_json
                self.decisions.append(decision)
                if len(self.decisions) == 2:
                    self.revision = 3
                    self.statuses[1] = "accepted"
                    self.jobs[0].update(status="done", completedRevision=3)
                self.jobs.append({"id": decision["id"], "noteId": decision["noteId"], "word": self.words[decision["noteId"]],
                                  "action": decision["action"], "status": "queued", "completedRevision": None})
            elif len(self.decisions) == 1:
                if self.scenario == "completion-race":
                    self.revision = 2
                    self.jobs[0]["status"] = "running"
                else:
                    self.revision = 3
                    self.statuses[1] = "accepted"
                    self.jobs[0].update(status="done", completedRevision=3)
            elif len(self.decisions) == 2:
                self.revision = 4
                self.statuses[2] = "accepted"
                self.jobs[1].update(status="done", completedRevision=4)
            return self.reply(route, self.jobs_view())
        if path == BASE + "/ai/queue":
            self.queue_reads += 1
            if self.external_complete:
                self.revision = 2
                self.statuses[1] = "accepted"
            kind = parse_qs(url.query).get("kind", ["review"])[0]
            allowed = {"review": {"proposed"}, "manual": {"flawed", "unresolved"}, "accepted": {"accepted", "corrected"}}[kind]
            items = [{"noteId": note_id, "word": self.words[note_id], "status": status, "batchId": "regression"}
                     for note_id, status in self.statuses.items() if status in allowed]
            if self.scenario == "stale-metadata" and self.queue_reads == 1 and kind == "review":
                items.insert(1, {"noteId": 2, "word": self.words[2], "status": "proposed", "batchId": "regression"})
            if self.scenario == "completion-race" and len(self.decisions) == 1:
                self.stale_poll_delivered = True
            return self.reply(route, {**self.summary(), "items": items})
        if path.startswith(BASE + "/ai/notes/"):
            note_id = int(path.rsplit("/", 1)[1])
            self.note_reads[note_id] += 1
            return self.reply(route, self.note(note_id))
        if path.startswith(BASE + "/images/"):
            if self.scenario == "completion-race" and path.endswith("/3/0") and len(self.decisions) < 2:
                self.delayed_images.append(route)
                return
            return route.fulfill(status=200, content_type="image/png", body=PNG)
        if path == BASE + "/ai/draft":
            self.delayed_drafts.append(route)
            return
        if path == BASE + "/preview":
            draft = request.post_data_json
            selected = [item["value"] for group in draft["groups"] for item in group if item.get("selected")]
            return self.reply(route, {"translationHtml": html.escape(", ".join(selected))})
        raise AssertionError(f"Unexpected backend request: {request.method} {path}")


def wait_browser(page, condition):
    deadline = time.monotonic() + 8
    while not condition():
        if time.monotonic() >= deadline:
            raise AssertionError("Timed out waiting for the controlled browser sequence")
        page.wait_for_timeout(10)
    # Let response handlers and React commit before issuing the next action.
    page.evaluate("() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))")


def open_review(browser, url, fixture):
    context = browser.new_context()
    page = context.new_page()
    errors = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.route("**/backend/**", fixture.route)
    page.goto(url)
    page.get_by_role("button", name="Review AI selections", exact=False).click()
    expect(page.get_by_role("heading", name="garden hose", exact=True)).to_be_visible()
    return context, page, errors


def main():
    if not (DIST / "index.html").exists():
        raise SystemExit("Build the frontend first: npm --prefix frontend run build")

    class QuietHandler(SimpleHTTPRequestHandler):
        def log_message(self, *_args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), partial(QuietHandler, directory=str(DIST)))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    url = f"http://127.0.0.1:{server.server_port}"
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(channel="chrome", headless=True)

            # Exact reported race: an old queue contains a running note; a newer
            # POST acknowledgment reports it done before the next queue poll.
            fixture = Fixture()
            context, page, errors = open_review(browser, url, fixture)
            wait_browser(page, lambda: fixture.note_reads[2] and fixture.delayed_images)
            page.keyboard.press("Meta+s")
            expect(page.get_by_role("heading", name="watering can", exact=True)).to_be_visible()
            wait_browser(page, lambda: fixture.stale_poll_delivered)
            page.keyboard.press("Meta+s")
            wait_browser(page, lambda: len(fixture.decisions) == 2)
            for route in fixture.delayed_images:
                route.fulfill(status=200, content_type="image/png", body=PNG)
            expect(page.get_by_role("heading", name="wheelbarrow", exact=True)).to_be_visible()
            expect(page.get_by_role("button", name="Accept & next", exact=True)).to_be_visible()
            wait_browser(page, lambda: fixture.jobs[-1]["status"] == "done")
            expect(page.get_by_role("heading", name="wheelbarrow", exact=True)).to_be_visible()
            assert [decision["noteId"] for decision in fixture.decisions] == [1, 2]
            assert fixture.note_reads[1] == 1, "The previously submitted note was resurrected"
            page.get_by_role("button", name="Accepted history (2)", exact=True).click()
            expect(page.get_by_role("heading", name="garden hose", exact=True)).to_be_visible()
            assert not errors, errors
            context.close()

            # Queue and cached payload may disagree independently of job receipts.
            fixture = Fixture("stale-metadata")
            context, page, errors = open_review(browser, url, fixture)
            wait_browser(page, lambda: fixture.note_reads[2] > 0)
            page.keyboard.press("Meta+s")
            expect(page.get_by_role("heading", name="wheelbarrow", exact=True)).to_be_visible()
            expect(page.get_by_role("button", name="Accept & next", exact=True)).to_be_visible()
            assert [decision["noteId"] for decision in fixture.decisions] == [1]
            assert not errors, errors
            context.close()

            # A clean displayed selection removed by polling must self-heal.
            fixture = Fixture("external")
            context, page, errors = open_review(browser, url, fixture)
            fixture.external_complete = True
            expect(page.get_by_role("heading", name="watering can", exact=True)).to_be_visible()
            expect(page.get_by_role("button", name="Accept & next", exact=True)).to_be_visible()
            assert fixture.decisions == []
            assert not errors, errors
            context.close()

            # Reconciliation must retain an unconfirmed/unsaved manual correction.
            fixture = Fixture("external-draft")
            context, page, errors = open_review(browser, url, fixture)
            page.get_by_role("button", name="Correct manually now", exact=True).click()
            page.get_by_role("button", name="Edit translation", exact=True).click()
            page.get_by_role("textbox", name="Translation text", exact=True).fill("keep my correction")
            fixture.external_complete = True
            expect(page.get_by_role("alert")).to_contain_text("Your correction is kept")
            expect(page.get_by_role("textbox", name="Translation text", exact=True)).to_have_value("keep my correction")
            expect(page.get_by_role("heading", name="garden hose", exact=True)).to_be_visible()
            assert fixture.decisions == []
            assert not errors, errors
            context.close()
            browser.close()
        print(json.dumps({"navigation_regression": "passed", "completion_race": "passed", "stale_prefetch": "passed",
                          "clean_selection_reconciliation": "passed", "unsaved_draft_preserved": "passed", "anki_requests": 0}))
    finally:
        server.shutdown()
        thread.join(5)
        server.server_close()


if __name__ == "__main__":
    main()
