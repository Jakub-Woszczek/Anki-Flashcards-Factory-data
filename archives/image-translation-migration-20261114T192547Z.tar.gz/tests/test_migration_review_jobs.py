from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import threading
import time
from unittest import TestCase
from unittest.mock import Mock, patch

from backend.image_translation_migration import AISelection, ImageTranslationMigration
from backend.migration_review_jobs import JobReference, ReviewDecision, ReviewJobQueue
from backend.services import FactoryService, ServiceError
from tests.test_image_translation_migration import FakeAnki


class TestReviewJobs(TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.factory = FactoryService.__new__(FactoryService)
        self.factory.diki = Mock()
        self.factory.diki.lookup.return_value = ([["zgniatać", "miażdżyć"]], [])
        self.factory._sync_after_mutation = Mock(return_value={"synced": True})
        self.factory.flush_sync = Mock(return_value={"synced": True})
        self.anki = FakeAnki()
        self.m = ImageTranslationMigration(self.factory, Path(self.temp.name) / "progress.json")
        self.m._anki = self.anki.invoke
        self.m.start()
        for note_id in (1, 2):
            ai = self.m.prepare_ai(note_id, "test")
            self.m.import_ai([AISelection(noteId=note_id, inputHash=ai["inputHash"], selectedIds=["0:1"],
                                          visualDescription="An object is crushed", reason="The physical meaning matches")])
        self.jobs = ReviewJobQueue(self.m)

    def decision(self, note_id=1, **updates):
        note = self.m.ai_note(note_id)
        return ReviewDecision.model_validate({"id": f"job-{note_id}", "noteId": note_id, "profileName": note["profileName"],
                                             "noteToken": note["noteToken"], "action": "accept",
                                             "expectedTranslation": note["fields"]["pl_translation"], **updates})

    def test_enqueue_has_no_anki_calls_or_evaluation_and_is_idempotent(self):
        request = self.decision()
        original = deepcopy(self.anki.notes)
        with patch.object(self.m, "_anki", side_effect=AssertionError("enqueue must not call Anki")):
            result = self.jobs.submit(request)
            self.assertEqual(self.jobs.submit(request)["pending"], 1)
        self.assertEqual(result["pending"], 1)
        self.assertEqual(self.m.status()["completed"], 0)
        self.assertEqual(self.anki.notes, original)
        self.jobs.process_one()
        self.assertEqual(self.jobs.snapshot()["jobs"][0]["status"], "done")
        self.assertEqual(self.jobs.submit(request)["pending"], 0)
        self.assertEqual(len(self.anki.writes), 1)

    def test_prefetched_tokens_work_across_unrelated_note_saves(self):
        first, second = self.decision(1), self.decision(2)
        self.jobs.submit(first)
        self.jobs.submit(second)
        self.jobs.process_one()
        first_receipt = self.jobs.snapshot()["jobs"][0]["completedRevision"]
        self.assertIsInstance(first_receipt, int)
        self.assertEqual(first_receipt, self.m.status()["revision"])
        self.jobs.process_one()
        self.assertEqual(self.jobs.snapshot()["jobs"][0]["completedRevision"], first_receipt)
        self.assertEqual(self.m.status()["completed"], 2)
        self.assertEqual([item["id"] for item in self.anki.writes], [1, 2])
        self.assertTrue(all(item["status"] == "done" for item in self.jobs.snapshot()["jobs"]))

    def test_slow_save_does_not_block_enqueue_or_prefetch_reads(self):
        first, second = self.decision(1), self.decision(2)
        entered, release = threading.Event(), threading.Event()
        original = self.m._anki

        def slow(action, **params):
            if action == "updateNoteFields":
                entered.set()
                if not release.wait(5):
                    raise RuntimeError("test did not release save")
            return original(action, **params)

        self.jobs.submit(first)
        self.m._anki = slow
        worker = threading.Thread(target=self.jobs.process_one)
        worker.start()
        self.assertTrue(entered.wait(2))
        try:
            start = time.monotonic()
            self.assertEqual(self.jobs.submit(second)["pending"], 2)
            self.assertEqual(self.m.ai_note(2)["noteId"], 2)
            self.assertEqual(len(self.m.ai_queue()["items"]), 2)
            self.assertLess(time.monotonic() - start, 0.5)
            state = self.m._read()
            self.assertEqual(state["completed"], [])
            self.assertEqual(state["items"]["1"]["ai"]["status"], "proposed")
        finally:
            release.set()
            worker.join(5)
        self.assertFalse(worker.is_alive())

    def test_failed_save_remains_unevaluated_and_retry_works(self):
        self.jobs.submit(self.decision())
        self.anki.fail_update = True
        self.jobs.process_one()
        self.assertEqual(self.jobs.snapshot()["failed"], 1)
        self.assertEqual(self.m.status()["completed"], 0)
        self.assertEqual(self.m.ai_note(1)["ai"]["status"], "proposed")
        self.anki.fail_update = False
        self.jobs.retry()
        self.jobs.process_one()
        self.assertEqual(self.jobs.snapshot()["failed"], 0)
        self.assertEqual(self.m.status()["completed"], 1)
        self.assertEqual(len(self.anki.writes), 1)

    def test_pending_jobs_resume_in_a_new_worker_instance(self):
        self.jobs.submit(self.decision())
        resumed = ReviewJobQueue(self.m)
        self.assertEqual(resumed.snapshot()["pending"], 1)
        resumed.process_one()
        self.assertEqual(self.m.status()["completed"], 1)

    def test_restart_after_anki_write_recovers_without_a_second_write(self):
        self.jobs.submit(self.decision(2))
        with patch.object(self.m, "_complete", side_effect=KeyboardInterrupt("simulated process exit")):
            with self.assertRaises(KeyboardInterrupt):
                self.jobs.process_one()
        self.assertEqual(self.jobs.snapshot()["jobs"][0]["status"], "running")
        self.assertEqual(len(self.anki.writes), 1)
        resumed = ReviewJobQueue(self.m)
        resumed.process_one()
        self.assertEqual(resumed.snapshot()["jobs"][0]["status"], "done")
        self.assertEqual(len(self.anki.writes), 1)
        self.assertEqual(self.m.status()["completed"], 1)

    def test_failed_job_can_return_to_review_without_marking_evaluated(self):
        request = self.decision()
        self.jobs.submit(request)
        self.anki.fail_update = True
        self.jobs.process_one()
        self.jobs.dismiss(JobReference(id=request.id))
        self.assertEqual(self.jobs.snapshot()["jobs"][0]["status"], "cancelled")
        self.assertEqual(self.m.status()["completed"], 0)
        self.anki.fail_update = False
        self.jobs.submit(self.decision(id="fresh-review"))
        self.jobs.process_one()
        self.assertEqual(self.m.status()["completed"], 1)

    def test_queued_manual_save_uses_captured_draft_not_current_screen(self):
        draft = {"lookupWord": "Crush", "groups": [[{"value": "captured & correct", "selected": True}]]}
        self.jobs.submit(self.decision(action="manual", draft=draft))
        draft["groups"][0][0]["value"] = "changed later"
        self.jobs.process_one()
        self.assertEqual(self.anki.writes[-1]["fields"], {"pl_translation": "captured &amp; correct"})
        self.assertEqual(self.m.ai_note(1)["ai"]["status"], "corrected")

    def test_queued_flawed_action_tags_without_writing_translation(self):
        self.jobs.submit(self.decision(action="flawed", reason="Wrong sense"))
        self.jobs.process_one()
        self.assertEqual(self.anki.writes, [])
        self.assertEqual(self.jobs.snapshot()["jobs"][0]["status"], "done")
        self.assertEqual(self.m.ai_note(1)["ai"]["status"], "flawed")

    def test_manual_job_rejects_image_changed_after_prefetch(self):
        self.jobs.submit(self.decision(action="manual", expectedImage=self.anki.notes[1]["fields"]["image"]["value"],
                                       imageDigests=[hashlib.sha256(self.anki.media_content).hexdigest()],
                                       draft={"lookupWord": "Crush", "groups": [[{"value": "manual", "selected": True}]]}))
        self.anki.media_content = b"replaced picture at the same filename"
        self.jobs.process_one()
        self.assertEqual(self.jobs.snapshot()["failed"], 1)
        self.assertEqual(self.m.status()["completed"], 0)
        self.assertEqual(self.anki.writes, [])

    def test_stale_same_note_token_and_wrong_profile_are_rejected(self):
        stale = self.decision()
        self.jobs.submit(stale)
        self.jobs.process_one()
        with self.assertRaises(ServiceError):
            self.jobs.submit(stale.model_copy(update={"id": "stale-repeat"}))
        with self.assertRaises(ServiceError):
            self.jobs.submit(self.decision(2, profileName="wrong"))
        self.assertEqual(len(self.anki.writes), 1)

    def test_worker_lifecycle_drains_and_syncs_outside_submission(self):
        self.jobs.submit(self.decision())
        self.factory.flush_sync.assert_not_called()
        self.jobs.start()
        self.jobs.stop()
        self.assertEqual(self.jobs.snapshot()["pending"], 0)
        self.assertEqual(self.m.status()["completed"], 1)
        self.factory.flush_sync.assert_called()

    def test_invalid_queue_is_not_reset(self):
        self.jobs.path.write_text("broken queue")
        with self.assertRaises(ServiceError):
            self.jobs.snapshot()
        self.assertEqual(self.jobs.path.read_text(), "broken queue")
