import base64
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
from pathlib import Path
import tempfile
from unittest import TestCase
from unittest.mock import Mock, patch

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.testclient import TestClient

from backend.image_translation_migration import (
    CommitRequest, DraftRequest, ImageTranslationMigration, LookupRequest, NOTE_TYPE, migration_router,
)
from backend.services import FactoryService, ServiceError
from external_APIs.diki_resources import ResourceError


def note(note_id, word, translation=""):
    return {"noteId": note_id, "modelName": NOTE_TYPE,
            "fields": {name: {"value": value} for name, value in {
                "en_word": word, "audio_en": "" if note_id == 2 else "[sound:original.mp3]",
                "pl_translation": translation, "image": '<img src="original.png">',
            }.items()}, "cards": [note_id + 100], "tags": ["keep-me"]}


class FakeAnki:
    def __init__(self):
        self.notes = {1: note(1, "Crush", "old translation"), 2: note(2, "mash")}
        self.profile = "Test profile"
        self.writes = []
        self.media_requests = []
        self.fail_update = False
        self.tag_writes = []
        self.media_content = b"image-bytes"
        self.fail_tags = False

    def invoke(self, action, **params):
        if action == "getActiveProfile":
            return self.profile
        if action == "findNotes":
            return list(self.notes)
        if action == "notesInfo":
            return deepcopy([self.notes[n] for n in params["notes"] if n in self.notes])
        if action == "updateNoteFields":
            if self.fail_update:
                raise ServiceError("Unavailable", 503)
            payload = params["note"]
            self.writes.append(deepcopy(payload))
            for field, value in payload["fields"].items():
                self.notes[payload["id"]]["fields"][field]["value"] = value
            return None
        if action == "retrieveMediaFile":
            self.media_requests.append(params["filename"])
            return base64.b64encode(self.media_content).decode()
        if action in {"addTags", "removeTags"}:
            if self.fail_tags:
                raise ServiceError("Tag update unavailable", 503)
            self.tag_writes.append((action, params["notes"], params["tags"]))
            for note_id in params["notes"]:
                tags = self.notes[note_id]["tags"]
                if action == "addTags" and params["tags"] not in tags:
                    tags.append(params["tags"])
                if action == "removeTags" and params["tags"] in tags:
                    tags.remove(params["tags"])
            return None
        raise AssertionError(f"Unexpected Anki operation: {action}")


class TestImageTranslationMigration(TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "progress.json"
        self.anki = FakeAnki()
        self.factory = FactoryService.__new__(FactoryService)
        self.factory.diki = Mock()
        self.factory.diki.lookup.return_value = ([["zgniatać", "miażdżyć"]], [])
        self.factory._sync_after_mutation = Mock(return_value={"synced": True, "syncPending": False})
        self.migration = self.instance()

    def instance(self):
        migration = ImageTranslationMigration(self.factory, self.path)
        migration._anki = self.anki.invoke
        return migration

    def draft(self, **updates):
        return {"lookupWord": "different dictionary spelling", "groups": [
            [{"original": "zgniatać", "value": "zgniatać & miażdżyć", "selected": True, "isBreak": False}]
        ], "lookedUp": True, "suggestions": [], **updates}

    def request(self, current, cls=DraftRequest, **updates):
        return cls(noteId=current["current"]["noteId"], revision=current["revision"],
                   draft=self.draft(), **updates)

    def test_snapshot_includes_translated_notes_and_missing_audio_and_never_restarts(self):
        current = self.migration.start()
        self.assertEqual(current["total"], 2)
        self.assertEqual(current["current"]["word"], "Crush")
        self.assertEqual(current["current"]["fields"]["pl_translation"], "old translation")
        self.anki.notes[3] = note(3, "new note")
        self.assertEqual(self.instance().start()["total"], 2)
        self.assertEqual(self.anki.writes, [])

    def test_overwrite_is_note_bound_and_preserves_everything_else(self):
        current = self.migration.start()
        before = deepcopy(self.anki.notes[1])
        result = self.migration.commit(self.request(current, CommitRequest, expectedTranslation="old translation"))
        self.assertEqual(self.anki.writes, [{"id": 1, "fields": {"pl_translation": "zgniatać &amp; miażdżyć"}}])
        before["fields"]["pl_translation"]["value"] = "zgniatać &amp; miażdżyć"
        self.assertEqual(self.anki.notes[1], before)
        self.assertEqual(result["completed"], 1)
        self.assertEqual(result["current"]["noteId"], 2)
        state = json.loads(self.path.read_text())
        self.assertEqual(state["items"]["1"]["originalFields"]["pl_translation"], "old translation")
        self.assertEqual(state["completed"], [1])
        self.assertEqual(state["pending"], [2])
        self.factory._sync_after_mutation.assert_called_once()
        self.factory.diki.fetch_audio.assert_not_called()

    def test_drafts_and_rotated_pending_queue_survive_new_instance(self):
        current = self.migration.start()
        self.migration.draft(self.request(current))
        resumed = self.instance().current()
        self.assertEqual(resumed["current"]["draft"]["lookupWord"], "different dictionary spelling")
        rotated = self.migration.skip(self.request(resumed))
        self.assertEqual((rotated["completed"], rotated["remaining"], rotated["current"]["noteId"]), (0, 2, 2))
        again = self.instance().skip(self.request(rotated))
        self.assertEqual(again["current"]["draft"], self.draft())

    def test_diki_lookup_preserves_note_identity_and_original_english(self):
        current = self.migration.start()
        result = self.migration.lookup(LookupRequest(noteId=1, revision=current["revision"], word="MASH"))
        self.assertEqual(result["draft"]["lookupWord"], "mash")
        self.factory.diki.lookup.assert_called_once_with("mash")
        resumed = self.instance().current()
        self.assertEqual(resumed["current"]["noteId"], 1)
        self.assertEqual(resumed["current"]["word"], "Crush")
        self.assertEqual(resumed["current"]["draft"]["groups"][0][0]["value"], "zgniatać")

    def test_late_lookup_cannot_replace_a_newer_draft(self):
        current = self.migration.start()
        self.factory.diki.lookup.side_effect = lambda _word: (self.migration.draft(self.request(current)) and ([[]], []))
        with self.assertRaises(ServiceError) as context:
            self.migration.lookup(LookupRequest(noteId=1, revision=current["revision"], word="crush"))
        self.assertEqual(context.exception.status_code, 409)
        self.assertEqual(self.migration.current()["current"]["draft"], self.draft())

    def test_diki_failure_keeps_note_pending_and_retains_draft(self):
        current = self.migration.start()
        self.factory.diki.lookup.side_effect = ResourceError("offline")
        with self.assertRaises(ServiceError):
            self.migration.lookup(LookupRequest(noteId=1, revision=current["revision"], word="crush"))
        self.assertEqual(self.migration.current()["remaining"], 2)
        self.assertEqual(self.anki.writes, [])

    def test_stale_requests_and_external_translation_changes_do_not_write(self):
        current = self.migration.start()
        self.migration.draft(self.request(current))
        with self.assertRaises(ServiceError):
            self.migration.commit(self.request(current, CommitRequest, expectedTranslation="old translation"))
        fresh = self.migration.current()
        self.anki.notes[1]["fields"]["pl_translation"]["value"] = "edited elsewhere"
        with self.assertRaises(ServiceError):
            self.migration.commit(self.request(fresh, CommitRequest, expectedTranslation="old translation"))
        self.assertEqual(self.anki.writes, [])

    def test_empty_or_break_only_selection_cannot_complete_a_note(self):
        current = self.migration.start()
        for groups in ([], [[{"value": "<br>", "selected": True}]]):
            request = CommitRequest(noteId=1, revision=current["revision"], expectedTranslation="old translation",
                                    draft=self.draft(groups=groups))
            with self.assertRaises(ServiceError):
                self.migration.commit(request)
        self.assertEqual(self.migration.current()["completed"], 0)

    def test_lost_response_recovers_verified_write_without_writing_again(self):
        current = self.migration.start()
        with patch.object(self.migration, "_complete", side_effect=OSError("simulated crash")):
            with self.assertRaises(OSError):
                self.migration.commit(self.request(current, CommitRequest, expectedTranslation="old translation"))
        self.assertIsNotNone(json.loads(self.path.read_text())["transaction"])
        resumed = self.instance().current()
        self.assertEqual((resumed["completed"], resumed["current"]["noteId"]), (1, 2))
        self.assertEqual(len(self.anki.writes), 1)
        self.factory._sync_after_mutation.assert_called_once()

    def test_failed_update_recovers_as_pending_and_can_be_retried(self):
        current = self.migration.start()
        self.anki.fail_update = True
        with self.assertRaises(ServiceError):
            self.migration.commit(self.request(current, CommitRequest, expectedTranslation="old translation"))
        resumed = self.instance().current()
        self.assertEqual((resumed["completed"], resumed["current"]["noteId"]), (0, 1))
        self.anki.fail_update = False
        self.migration.commit(self.request(resumed, CommitRequest, expectedTranslation="old translation"))
        self.assertEqual(self.migration.current()["completed"], 1)

    def test_recovery_conflict_keeps_journal_and_does_not_overwrite(self):
        current = self.migration.start()
        self.anki.fail_update = True
        with self.assertRaises(ServiceError):
            self.migration.commit(self.request(current, CommitRequest, expectedTranslation="old translation"))
        self.anki.notes[1]["fields"]["pl_translation"]["value"] = "third-party change"
        with self.assertRaises(ServiceError):
            self.instance().current()
        self.assertIsNotNone(json.loads(self.path.read_text())["transaction"])
        self.assertEqual(self.anki.writes, [])

    def test_wrong_profile_changed_type_or_english_cannot_be_saved(self):
        current = self.migration.start()
        self.anki.profile = "Other"
        with self.assertRaises(ServiceError):
            self.migration.current()
        self.anki.profile = "Test profile"
        self.anki.notes[1]["modelName"] = "Other type"
        with self.assertRaises(ServiceError):
            self.migration.current()
        self.anki.notes[1]["modelName"] = NOTE_TYPE
        self.anki.notes[1]["fields"]["en_word"]["value"] = "new word"
        with self.assertRaises(ServiceError):
            self.migration.commit(self.request(current, CommitRequest, expectedTranslation="old translation"))
        self.assertEqual(self.anki.writes, [])

    def test_corrupt_progress_is_never_reset(self):
        self.path.write_text("broken JSON")
        with self.assertRaises(ServiceError):
            self.migration.start()
        self.assertEqual(self.path.read_text(), "broken JSON")

    def test_transport_distinguishes_successful_null_writes_from_anki_errors(self):
        self.factory.anki = Mock(anki_URL="http://anki.test.invalid")
        migration = ImageTranslationMigration(self.factory, self.path)
        response = Mock()
        with patch("requests.post", return_value=response) as post:
            response.json.return_value = {"result": None, "error": None}
            self.assertIsNone(migration._anki("updateNoteFields", note={"id": 1, "fields": {"pl_translation": "test"}}))
            self.assertEqual(post.call_args.kwargs["json"]["action"], "updateNoteFields")
            for payload in ({"result": None, "error": "Update rejected"}, {}, []):
                response.json.return_value = payload
                with self.assertRaises(ServiceError):
                    migration._anki("updateNoteFields", note={"id": 1, "fields": {"pl_translation": "test"}})

    def test_atomic_write_failure_leaves_previous_file_intact(self):
        current = self.migration.start()
        original = self.path.read_bytes()
        with patch("backend.image_translation_migration.os.replace", side_effect=OSError("disk failure")):
            with self.assertRaises(OSError):
                self.migration.draft(self.request(current))
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(list(self.path.parent.glob("*.tmp")), [])

    def test_images_are_restricted_to_filenames_in_snapshot_notes(self):
        self.migration.start()
        response = self.migration.image(1, 0)
        self.assertEqual(response.body, b"image-bytes")
        self.assertEqual(response.media_type, "image/png")
        self.assertEqual(self.anki.media_requests, ["original.png"])
        self.anki.notes[1]["fields"]["image"]["value"] = '<img src="../secret.png"><img src="https://example.com/a.png">'
        with self.assertRaises(ServiceError):
            self.migration.image(1, 0)
        with self.assertRaises(ServiceError):
            self.migration.image(999, 0)
        self.assertEqual(self.anki.media_requests, ["original.png"])

    def test_concurrent_saves_from_two_tabs_only_update_once(self):
        current = self.migration.start()
        request = self.request(current, CommitRequest, expectedTranslation="old translation")

        def save():
            try:
                return self.instance().commit(request)["completed"]
            except ServiceError as error:
                return error.status_code

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: save(), range(2)))
        self.assertCountEqual(results, [1, 409])
        self.assertEqual(len(self.anki.writes), 1)
        self.assertEqual(self.migration.current()["completed"], 1)

    def test_last_save_completes_migration_and_start_keeps_it_completed(self):
        current = self.migration.start()
        current = self.migration.commit(self.request(current, CommitRequest, expectedTranslation="old translation"))
        current = self.migration.commit(self.request(current, CommitRequest, expectedTranslation=""))
        self.assertIsNone(current["current"])
        self.assertEqual((current["completed"], current["remaining"]), (2, 0))
        self.assertIsNone(self.instance().start()["current"])

    def test_http_routes_coerce_image_ids_validate_requests_and_escape_previews(self):
        app = FastAPI()

        @app.exception_handler(ServiceError)
        async def error_handler(_request: Request, error: ServiceError):
            return JSONResponse(status_code=error.status_code, content={"detail": error.message})

        with patch("backend.image_translation_migration.ImageTranslationMigration", return_value=self.migration):
            app.include_router(migration_router(self.factory))
        with TestClient(app) as client:
            base = "/backend/image-translation-migration"
            self.assertFalse(client.get(base + "/status").json()["started"])
            self.assertFalse(self.path.exists())
            result = client.post(base + "/start")
            self.assertEqual(result.status_code, 200)
            image = client.get(base + "/images/1/0")
            self.assertEqual(image.status_code, 200)
            self.assertEqual(image.content, b"image-bytes")
            self.assertEqual(client.get(base + "/images/not-an-id/0").status_code, 422)
            self.assertEqual(client.patch(base + "/draft", json={"noteId": 1}).status_code, 422)
            preview = client.post(base + "/preview", json=self.draft(groups=[[
                {"value": '<script>alert("x")</script>', "selected": True},
                {"value": "<br>", "selected": True},
            ], [{"value": "second", "selected": True}]]))
            self.assertEqual(preview.status_code, 200)
            self.assertEqual(preview.json()["translationHtml"],
                             "&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;<br>\nsecond")
            current = result.json()
            committed = client.post(base + "/commit", json=self.request(
                current, CommitRequest, expectedTranslation="old translation").model_dump())
            self.assertEqual(committed.status_code, 200)
            self.assertEqual(committed.json()["completed"], 1)
