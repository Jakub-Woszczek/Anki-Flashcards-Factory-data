from copy import deepcopy
import json
from pathlib import Path
import tempfile
from unittest import TestCase
from unittest.mock import Mock, patch

from backend.image_translation_migration import (
    AIFlawedRequest, AIManualRequest, AIReviewRequest, AISelection,
    CommitRequest, DraftRequest, ImageTranslationMigration, LookupRequest, FLAWED_TAG,
)
from backend.services import FactoryService, ServiceError
from tests.test_image_translation_migration import FakeAnki
from tools.image_translation_ai import prepare


class TestImageTranslationAI(TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "progress.json"
        self.factory = FactoryService.__new__(FactoryService)
        self.factory.diki = Mock()
        self.factory.diki.lookup.return_value = ([["zgniatać", "miażdżyć"], ["tłok"]], [])
        self.factory._sync_after_mutation = Mock(return_value={"synced": True})
        self.anki = FakeAnki()
        self.m = self.instance()
        self.m.start()

    def instance(self):
        migration = ImageTranslationMigration(self.factory, self.path)
        migration._anki = self.anki.invoke
        return migration

    def proposal(self, note_id=1, **updates):
        prepared = self.m.prepare_ai(note_id, "pilot-test")
        result = AISelection(noteId=note_id, inputHash=prepared["inputHash"], selectedIds=["0:1"],
                             visualDescription="An object is being crushed.", reason="The image depicts physical crushing.", **updates)
        self.m.import_ai([result])
        return result

    def accept_request(self, note_id=1):
        note = self.m.ai_note(note_id)
        return AIReviewRequest(noteId=note_id, revision=note["revision"], expectedTranslation=note["fields"]["pl_translation"])

    def test_prepare_import_are_not_completion_or_anki_writes(self):
        original = deepcopy(self.anki.notes)
        result = self.proposal()
        self.assertEqual(self.anki.notes, original)
        self.assertEqual(self.anki.writes, [])
        self.assertEqual(self.anki.tag_writes, [])
        self.assertEqual(self.m.status()["completed"], 0)
        self.assertEqual(self.m.status()["aiCounts"]["proposed"], 1)
        revision = self.m.status()["revision"]
        self.m.import_ai([result])
        self.assertEqual(self.m.status()["revision"], revision)
        self.factory._sync_after_mutation.assert_not_called()

    def test_review_preserves_exact_candidates_and_shows_all_note_fields(self):
        self.proposal()
        self.factory.diki.lookup.return_value = ([["new dictionary content"]], [])
        value = self.instance().ai_note(1)
        self.assertEqual(value["ai"]["groups"], [["zgniatać", "miażdżyć"], ["tłok"]])
        self.assertEqual(value["proposalHtml"], "miażdżyć")
        self.assertEqual(value["audioCount"], 1)
        self.assertEqual(set(value["fields"]), {"en_word", "audio_en", "pl_translation", "image"})
        self.assertTrue(value["draft"]["groups"][0][1]["selected"])

    def test_accept_arbitrary_pending_note_writes_only_translation(self):
        self.proposal(2)
        before = deepcopy(self.anki.notes[2])
        self.m.ai_accept(self.accept_request(2))
        before["fields"]["pl_translation"]["value"] = "miażdżyć"
        self.assertEqual(self.anki.notes[2], before)
        self.assertEqual(self.anki.writes, [{"id": 2, "fields": {"pl_translation": "miażdżyć"}}])
        self.assertEqual(self.m.current()["current"]["noteId"], 1)
        self.assertEqual(self.instance().ai_queue("accepted")["items"][0]["noteId"], 2)
        self.assertEqual(self.m.ai_queue("review")["items"], [])
        with self.assertRaises(ServiceError):
            self.m.ai_accept(self.accept_request(2))

    def test_flawed_tag_and_manual_draft_correction_survive_restart(self):
        self.proposal(2)
        value = self.m.ai_note(2)
        self.m.ai_flawed(AIFlawedRequest(noteId=2, revision=value["revision"], reason="Wrong sense"))
        self.assertIn(FLAWED_TAG, self.anki.notes[2]["tags"])
        self.assertEqual(self.anki.writes, [])
        value = self.m.ai_note(2)
        draft = value["draft"]
        draft["groups"] = [[{"value": "ręcznie & poprawnie", "selected": True}]]
        self.m.ai_draft(DraftRequest(noteId=2, revision=value["revision"], draft=draft))
        value = self.instance().ai_note(2)
        self.assertEqual(value["draft"]["groups"][0][0]["value"], "ręcznie & poprawnie")
        self.m.ai_manual(AIManualRequest(noteId=2, revision=value["revision"], expectedTranslation="", draft=value["draft"]))
        self.assertEqual(self.anki.writes[-1]["fields"], {"pl_translation": "ręcznie &amp; poprawnie"})
        self.assertNotIn(FLAWED_TAG, self.anki.notes[2]["tags"])
        self.assertIn("keep-me", self.anki.notes[2]["tags"])
        self.assertEqual(self.m.ai_note(2)["ai"]["status"], "corrected")

    def test_unresolved_goes_to_manual_queue_and_cannot_be_accepted(self):
        prepared = self.m.prepare_ai(1, "pilot-test")
        self.m.import_ai([AISelection(noteId=1, inputHash=prepared["inputHash"], selectedIds=[],
                                      visualDescription="Unclear picture", reason="Cannot match the sense", needsReview=True)])
        self.assertEqual(len(self.m.ai_queue("manual")["items"]), 1)
        with self.assertRaises(ServiceError):
            self.m.ai_accept(self.accept_request())
        self.assertEqual(self.anki.writes, [])

    def test_unknown_duplicate_or_empty_choices_are_rejected_atomically(self):
        prepared = self.m.prepare_ai(1, "pilot-test")
        for ids in (["0:99"], ["0:1", "0:1"], []):
            with self.assertRaises(ServiceError):
                self.m.import_ai([AISelection(noteId=1, inputHash=prepared["inputHash"], selectedIds=ids,
                                              visualDescription="Picture", reason="Choice")])
        self.assertEqual(self.m.status()["aiCounts"]["prepared"], 1)

    def test_image_bytes_changed_at_same_filename_block_acceptance(self):
        self.proposal()
        self.anki.media_content = b"a completely different picture"
        with self.assertRaises(ServiceError):
            self.m.ai_accept(self.accept_request())
        self.assertEqual(self.anki.writes, [])

    def test_changed_inputs_or_results_cannot_override_existing_proposal(self):
        result = self.proposal()
        for changed in (result.model_copy(update={"inputHash": "wrong"}), result.model_copy(update={"selectedIds": ["1:0"]})):
            with self.assertRaises(ServiceError):
                self.m.import_ai([changed])
        self.assertEqual(self.m.ai_note(1)["proposalHtml"], "miażdżyć")

    def test_interrupted_non_head_acceptance_recovers_exactly_once(self):
        self.proposal(2)
        request = self.accept_request(2)
        with patch.object(self.m, "_complete", side_effect=OSError("crash")):
            with self.assertRaises(OSError):
                self.m.ai_accept(request)
        value = self.instance().ai_note(2)
        self.assertEqual(value["ai"]["status"], "accepted")
        self.assertEqual(self.m.status()["completed"], 1)
        self.assertEqual(len(self.anki.writes), 1)

    def test_tag_failure_is_reconciled_without_losing_flawed_status(self):
        self.proposal()
        value = self.m.ai_note(1)
        self.anki.fail_tags = True
        with self.assertRaises(ServiceError):
            self.m.ai_flawed(AIFlawedRequest(noteId=1, revision=value["revision"]))
        state = json.loads(self.path.read_text())
        self.assertTrue(state["items"]["1"]["ai"]["tagPending"])
        self.anki.fail_tags = False
        self.instance().ai_note(1)
        self.assertIn(FLAWED_TAG, self.anki.notes[1]["tags"])
        self.assertEqual(self.anki.writes, [])

    def test_accept_history_can_be_marked_flawed_and_reopened(self):
        result = self.proposal()
        self.m.ai_accept(self.accept_request())
        self.m.import_ai([result])  # rerunning an identical results file is harmless
        value = self.m.ai_note(1)
        self.m.ai_flawed(AIFlawedRequest(noteId=1, revision=value["revision"]))
        self.assertEqual(self.m.status()["completed"], 0)
        self.assertEqual(self.m.ai_queue("manual")["items"][0]["noteId"], 1)
        self.assertEqual(len(self.anki.writes), 1)

    def test_manual_lookup_keeps_original_note_id_and_persisted_candidates(self):
        self.proposal(2)
        value = self.m.ai_note(2)
        self.factory.diki.lookup.return_value = ([["other meaning"]], ["suggestion"])
        value = self.m.ai_lookup(LookupRequest(noteId=2, revision=value["revision"], word="another spelling"))
        self.assertEqual(value["fields"]["en_word"], "mash")
        self.assertEqual(value["draft"]["lookupWord"], "another spelling")
        self.assertEqual(value["ai"]["groups"][0], ["zgniatać", "miażdżyć"])

    def test_helper_export_is_resumable_and_does_not_call_an_ai_service(self):
        path = prepare(self.m, "pilot-test", 2, spread=True)
        manifest = json.loads(path.read_text())
        self.assertEqual(len(manifest["notes"]), 2)
        self.assertEqual(manifest["notes"][0]["groups"][0][0], {"id": "0:0", "text": "zgniatać"})
        self.assertTrue((path.parent / manifest["notes"][0]["images"][0]).exists())
        self.assertEqual(self.anki.writes, [])
        self.assertEqual(prepare(self.instance(), "pilot-test", 2), path)
        self.assertEqual(self.factory.diki.lookup.call_count, 2)

    def test_human_completion_during_preparation_cannot_be_overwritten(self):
        prepared = self.m.prepare_ai(1, "pilot-test")
        current = self.m.current()
        self.m.commit(CommitRequest(noteId=1, revision=current["revision"], expectedTranslation="old translation",
                                   draft={"lookupWord": "Crush", "groups": [[{"value": "human choice", "selected": True}]]}))
        state = json.loads(self.path.read_text())
        self.assertNotIn("ai", state["items"]["1"])
        self.assertIn("cancelledAIPreparation", state["items"]["1"])
        self.assertEqual(self.m.ai_queue("accepted")["items"], [])
        with self.assertRaises(ServiceError):
            self.m.import_ai([AISelection(noteId=1, inputHash=prepared["inputHash"], selectedIds=["0:0"],
                                          visualDescription="Picture", reason="A late worker result")])
        self.assertEqual(self.anki.notes[1]["fields"]["pl_translation"]["value"], "human choice")
        self.assertEqual(self.m.status()["completed"], 1)

    def test_audio_reads_only_a_recording_from_the_target_note(self):
        response = self.m.audio(1, 0)
        self.assertEqual(response.body, self.anki.media_content)
        self.assertEqual(response.media_type, "audio/mpeg")
        self.assertEqual(self.anki.media_requests, ["original.mp3"])
        self.anki.notes[1]["fields"]["audio_en"]["value"] = "[sound:../private.mp3]"
        with self.assertRaises(ServiceError):
            self.m.audio(1, 0)
        with self.assertRaises(ServiceError):
            self.m.audio(2, 0)
        self.assertEqual(self.anki.writes, [])
