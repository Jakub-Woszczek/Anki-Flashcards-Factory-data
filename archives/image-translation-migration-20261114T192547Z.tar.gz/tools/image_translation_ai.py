"""Prepare/import assistant-processed image batches; no external AI API calls."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile

from dotenv import load_dotenv

from backend.image_translation_migration import AISelection, ImageTranslationMigration, PROGRESS_PATH
from backend.services import FactoryService, ServiceError
from backend.settings import ROOT_DIR
from external_APIs.ankiConnect import AnkiConnect
from external_APIs.dikiApi import DikiApi
from external_APIs.diki_resources import DikiResources


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary and temporary.exists():
            temporary.unlink()


def prepare(migration, batch_id, count, spread=False, note_ids=None):
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", batch_id):
        raise ValueError("Use a batch name containing letters, digits, hyphens or underscores")
    folder = migration.path.parent / "ai-batches" / batch_id
    manifest_path = folder / "manifest.json"
    with migration._locked():
        state = migration._read()
        if state is None:
            raise ValueError("Start the migration in the app before preparing AI batches")
        migration._profile(state)
        if manifest_path.exists():
            manifest = json.loads(manifest_path.read_text())
            if manifest["profileName"] != state["profileName"] or manifest["batchId"] != batch_id:
                raise ValueError("The batch manifest belongs to another profile or batch")
            selected = manifest["noteIds"]
        else:
            # Include partially prepared notes when resuming a terminated export.
            own = [n for n in state["pending"] if state["items"][str(n)].get("ai", {}).get("batchId") == batch_id]
            available = [n for n in state["pending"] if not state["items"][str(n)].get("ai")]
            if note_ids:
                selected = note_ids
                if len(set(selected)) != len(selected) or any(n not in available + own for n in selected):
                    raise ValueError("Explicit IDs must be distinct, pending and unassigned to another batch")
            else:
                count = min(count, len(available))
                chosen = ([available[round(i * (len(available) - 1) / (count - 1))] for i in range(count)]
                          if spread and count > 1 else available[:count])
                selected = own + chosen
            manifest = {"batchId": batch_id, "profileName": state["profileName"], "noteIds": selected, "notes": []}
            atomic_json(manifest_path, manifest)
    existing = {item["noteId"]: item for item in manifest["notes"]}
    for note_id in selected:
        if note_id in existing:
            continue
        ai = migration.prepare_ai(note_id, batch_id)
        images = []
        for index, image in enumerate(ai["images"]):
            content = migration.image(note_id, index).body
            if hashlib.sha256(content).hexdigest() != image["digest"]:
                raise ValueError(f"Image changed while exporting note {note_id}")
            filename = f"{note_id}-{index}{Path(image['filename']).suffix.lower()}"
            (folder / filename).write_bytes(content)
            images.append(filename)
        item = {"noteId": note_id, "word": ai["snapshotFields"]["en_word"], "inputHash": ai["inputHash"],
                "images": images, "preparationError": ai["preparationError"],
                "groups": [[{"id": f"{gi}:{ti}", "text": text} for ti, text in enumerate(group)]
                           for gi, group in enumerate(ai["groups"])]}
        manifest["notes"].append(item)
        atomic_json(manifest_path, manifest)
        print(f"Prepared {len(manifest['notes'])}/{len(selected)}: {item['word']}", flush=True)
    return manifest_path


def main(argv=None):
    load_dotenv(ROOT_DIR / ".env")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--progress", type=Path, default=PROGRESS_PATH)
    commands = parser.add_subparsers(dest="command", required=True)
    batch = commands.add_parser("prepare")
    batch.add_argument("--batch", required=True)
    batch.add_argument("--count", type=int, default=20)
    batch.add_argument("--spread", action="store_true", help="Sample across the pending queue for the pilot")
    batch.add_argument("--note-ids", help="Optional comma-separated pending note IDs")
    commands.add_parser("status")
    ingest = commands.add_parser("import")
    ingest.add_argument("--results", type=Path, required=True)
    args = parser.parse_args(argv)
    # Reuse only Anki, Diki and pure formatting helpers. Do not initialize normal
    # sessions, the word index or a Gemini client for this local assistant tool.
    factory = FactoryService.__new__(FactoryService)
    factory.anki = AnkiConnect()
    migration = ImageTranslationMigration(factory, args.progress)
    try:
        if args.command == "status":
            print(json.dumps(migration.status(), ensure_ascii=False, indent=2))
        elif args.command == "import":
            payload = json.loads(args.results.read_text(encoding="utf-8"))
            results = [AISelection.model_validate(row) for row in payload["results"]]
            print(json.dumps(migration.import_ai(results), ensure_ascii=False, indent=2))
        else:
            if args.count < 1:
                parser.error("count must be positive")
            ids = [int(value) for value in args.note_ids.split(",")] if args.note_ids else None
            with DikiResources() as resources:
                factory.diki = DikiApi(resources)
                path = prepare(migration, args.batch, args.count, args.spread, ids)
            print(path)
    except (ServiceError, ValueError, OSError) as error:
        print(f"AI batch failed: {error}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
