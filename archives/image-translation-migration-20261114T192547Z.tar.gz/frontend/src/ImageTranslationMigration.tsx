import { useEffect, useRef, useState } from 'react'
import { api } from './api'
import { TranslationEditor } from './TranslationEditor'
import { MigrationImage } from './MigrationMedia'
import type { Translation } from './types'
import './image-translation-migration.css'

const BASE = '/backend/image-translation-migration'

type MigrationDraft = {
  lookupWord: string
  groups: Translation[][]
  suggestions: string[]
  lookedUp: boolean
}

type Progress = {
  started: boolean
  noteType: string
  progressPath: string
  profileName?: string
  total?: number
  completed?: number
  remaining?: number
  revision?: number
  aiCounts?: Record<string, number>
}

type CurrentNote = {
  noteId: number
  word: string
  fields: Record<string, string>
  draft: MigrationDraft
  imageCount: number
}

type MigrationState = Progress & { revision: number; current: CurrentNote | null }
type SaveResult = MigrationState & { syncWarning?: string; syncPending?: boolean; savedNoteId?: number }

function message(error: unknown) {
  return error instanceof Error ? error.message : 'The migration request failed.'
}

function plainText(value: string) {
  return new DOMParser().parseFromString(value.replace(/<br\s*\/?\s*>/gi, '\n'), 'text/html').body.textContent ?? ''
}

export function ImageTranslationMigrationEntry({ onOpen, onAIReview }: { onOpen: () => void; onAIReview: (kind: 'review' | 'manual' | 'accepted') => void }) {
  const [progress, setProgress] = useState<Progress | null>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    void api.get<Progress>(`${BASE}/status`).then(setProgress).catch((error) => setError(message(error)))
  }, [])

  return <section className="panel image-migration-entry">
    <div><p className="eyebrow">ONE-TIME MIGRATION</p><h2>Polish translations for image notes</h2>
      <p>Work through every Basic [reverse+audio+image] note across all decks. Save a new translation on each existing note, including those already translated.</p>
      {progress?.started ? <p><strong>{progress.completed} / {progress.total} completed</strong> · {progress.remaining} remaining · JSON progress saved locally</p> : <p>Progress and drafts are saved between batches.</p>}
      {error ? <p className="inline-error">{error}</p> : null}
    </div>
    <div className="image-migration-entry-actions">
      <button className="button button--primary" type="button" onClick={onOpen}>{progress?.started ? progress.remaining ? 'Resume migration' : 'View completed migration' : 'Start migration'}</button>
      {progress?.started ? <>
        <button className="button button--secondary" type="button" onClick={() => onAIReview('review')}>Review AI selections ({progress.aiCounts?.proposed ?? 0})</button>
        <button className="button button--secondary" type="button" onClick={() => onAIReview('manual')}>Fix flawed / unresolved ({(progress.aiCounts?.flawed ?? 0) + (progress.aiCounts?.unresolved ?? 0)})</button>
        <button className="text-button" type="button" onClick={() => onAIReview('accepted')}>Accepted AI history ({(progress.aiCounts?.accepted ?? 0) + (progress.aiCounts?.corrected ?? 0)})</button>
      </> : null}
    </div>
  </section>
}

export function ImageTranslationMigration({ onExit }: { onExit: () => void }) {
  const [view, setView] = useState<MigrationState | null>(null)
  const [draft, setDraft] = useState<MigrationDraft | null>(null)
  const [busy, setBusy] = useState(true)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [draftStatus, setDraftStatus] = useState('Saved locally')
  const [preview, setPreview] = useState('')
  const [previewError, setPreviewError] = useState('')
  const [aiText, setAiText] = useState('')
  const viewRef = useRef<MigrationState | null>(null)
  const draftRef = useRef<MigrationDraft | null>(null)
  const revision = useRef(0)
  const edits = useRef(0)
  const savedEdits = useRef(0)
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const serial = useRef<Promise<unknown>>(Promise.resolve())
  const opened = useRef(false)

  // Serialize local mutations. Each queued request uses the revision returned by
  // its predecessor; an old autosave can never land after saving/skipping a note.
  function enqueue<T,>(job: () => Promise<T>): Promise<T> {
    const next = serial.current.then(job)
    serial.current = next.catch(() => undefined)
    return next
  }

  function cancelTimer() {
    if (timer.current) window.clearTimeout(timer.current)
    timer.current = undefined
  }

  function summary(progress: Progress) {
    revision.current = progress.revision ?? revision.current
    if (viewRef.current) {
      viewRef.current = { ...viewRef.current, ...progress, revision: revision.current }
      setView(viewRef.current)
    }
  }

  function adopt(next: MigrationState) {
    viewRef.current = next
    revision.current = next.revision
    draftRef.current = next.current?.draft ?? null
    edits.current = 0
    savedEdits.current = 0
    setView(next)
    setDraft(draftRef.current)
    setDraftStatus('Saved locally')
    setAiText('')
    setPreview('')
  }

  async function persist(noteId: number, value: MigrationDraft, editVersion: number) {
    if (viewRef.current?.current?.noteId !== noteId) return
    setDraftStatus('Saving draft…')
    const progress = await api.patch<Progress>(`${BASE}/draft`, { noteId, revision: revision.current, draft: value })
    summary(progress)
    savedEdits.current = editVersion
    setDraftStatus(edits.current === editVersion ? 'Saved locally' : 'Unsaved edits…')
  }

  async function flushDraft() {
    const noteId = viewRef.current?.current?.noteId
    if (noteId && draftRef.current && edits.current !== savedEdits.current) {
      await persist(noteId, draftRef.current, edits.current)
    }
  }

  function changeDraft(next: MigrationDraft) {
    const noteId = viewRef.current?.current?.noteId
    if (!noteId) return
    draftRef.current = next
    edits.current += 1
    const editVersion = edits.current
    setDraft(next)
    setDraftStatus('Unsaved edits…')
    cancelTimer()
    timer.current = window.setTimeout(() => {
      void enqueue(() => persist(noteId, next, editVersion)).catch((error) => {
        setError(message(error))
        setDraftStatus('Draft could not be saved — retry before exiting')
      })
    }, 550)
  }

  async function lookupNow(word: string) {
    const noteId = viewRef.current?.current?.noteId
    if (!noteId) return
    const result = await api.post<Progress & { draft: MigrationDraft }>(`${BASE}/lookup`, { noteId, revision: revision.current, word })
    summary(result)
    draftRef.current = result.draft
    setDraft(result.draft)
    savedEdits.current = edits.current
    setDraftStatus('Saved locally')
  }

  async function autoLookup() {
    if (draftRef.current && !draftRef.current.lookedUp) await lookupNow(draftRef.current.lookupWord)
  }

  async function run(job: () => Promise<void>) {
    cancelTimer()
    setBusy(true)
    setError('')
    try {
      await enqueue(job)
    } catch (error) {
      setError(message(error))
    } finally {
      setBusy(false)
    }
  }

  async function open() {
    await run(async () => {
      adopt(await api.post<MigrationState>(`${BASE}/start`))
      await autoLookup()
    })
  }

  useEffect(() => {
    // React development StrictMode replays effects; initialization is idempotent
    // in the backend too, but avoid duplicate dictionary requests in this tab.
    if (!opened.current) { opened.current = true; void open() }
    return cancelTimer
  }, [])

  useEffect(() => {
    function warn(event: BeforeUnloadEvent) {
      if (edits.current !== savedEdits.current) { event.preventDefault(); event.returnValue = '' }
    }
    window.addEventListener('beforeunload', warn)
    return () => window.removeEventListener('beforeunload', warn)
  }, [])

  useEffect(() => {
    if (!draft) return
    let current = true
    setPreviewError('')
    const timeout = window.setTimeout(() => {
      void api.post<{ translationHtml: string }>(`${BASE}/preview`, draft).then((result) => {
        if (current) setPreview(result.translationHtml)
      }).catch((error) => { if (current) setPreviewError(message(error)) })
    }, 180)
    return () => { current = false; window.clearTimeout(timeout) }
  }, [draft])

  async function save() {
    await run(async () => {
      await flushDraft()
      const note = viewRef.current?.current
      if (!note || !draftRef.current) return
      const result = await api.post<SaveResult>(`${BASE}/commit`, {
        noteId: note.noteId, revision: revision.current, draft: draftRef.current,
        expectedTranslation: note.fields.pl_translation,
      })
      adopt(result)
      setNotice(`Saved translation on note ${result.savedNoteId}.${result.syncWarning ? ` AnkiWeb sync pending: ${result.syncWarning}` : result.syncPending ? ' AnkiWeb sync is queued.' : ''}`)
      await autoLookup()
    })
  }

  async function skip() {
    await run(async () => {
      await flushDraft()
      const noteId = viewRef.current?.current?.noteId
      if (!noteId || !draftRef.current) return
      adopt(await api.post<MigrationState>(`${BASE}/skip`, { noteId, revision: revision.current, draft: draftRef.current }))
      setNotice('Kept pending and moved to the end of the queue. Its draft is saved.')
      await autoLookup()
    })
  }

  async function exit() {
    await run(async () => { await flushDraft(); onExit() })
  }

  async function reload() {
    await run(async () => {
      // Recover an interrupted save or refresh a stale revision. Keep unsaved
      // selections if the queue still points at this same note.
      const oldNoteId = viewRef.current?.current?.noteId
      const unsaved = edits.current !== savedEdits.current ? draftRef.current : null
      const next = await api.get<MigrationState>(`${BASE}/current`)
      adopt(next)
      if (unsaved && next.current?.noteId === oldNoteId) {
        changeDraft(unsaved)
        cancelTimer()
        await flushDraft()
      }
      await autoLookup()
    })
  }

  async function askAI() {
    await run(async () => {
      await flushDraft()
      const value = draftRef.current
      if (!value) return
      const result = await api.post<{ text: string }>('/backend/gemini/translate', {
        word: value.lookupWord,
        dikiTranslations: value.groups.map((group) => group.filter((item) => !item.isBreak && item.original).map((item) => item.original)).filter((group) => group.length),
      })
      setAiText(result.text)
    })
  }

  const current = view?.current
  const hasTranslation = draft?.groups.some((group) => group.some((item) => item.selected && !item.isBreak && item.value.trim() && item.value.trim() !== '<br>'))
  const selected = draft?.groups.flat().filter((item) => item.selected && !item.isBreak).length ?? 0

  useEffect(() => {
    function saveShortcut(event: KeyboardEvent) {
      if (!event.metaKey || event.ctrlKey || event.altKey || event.shiftKey || event.key.toLowerCase() !== 's') return
      event.preventDefault()
      if (!event.repeat && !busy && current && hasTranslation) void save()
    }
    window.addEventListener('keydown', saveShortcut)
    return () => window.removeEventListener('keydown', saveShortcut)
  })

  return <main className="workspace-shell image-migration">
    <header className="topbar workspace-topbar">
      <div className="brand"><span className="brand__mark">AF</span><span>Image translation migration</span></div>
      {view ? <div className="queue-meter"><strong>{view.completed} / {view.total}</strong><span>completed · {view.remaining} remaining</span></div> : null}
      <button className="button button--secondary" type="button" disabled={busy} onClick={() => void exit()}>Save draft & exit</button>
    </header>
    {error ? <div className="notice notice--error" role="alert"><p>{error}</p><button className="button button--secondary" type="button" disabled={busy} onClick={() => void (view ? reload() : open())}>{view ? 'Reload current note' : 'Retry opening migration'}</button></div> : null}
    {notice ? <div className="notice notice--success" role="status">{notice}</div> : null}
    {!view ? <p className="loading-mark">{busy ? 'Opening migration and looking up translations…' : 'The migration could not be opened.'}</p> : !current ? <section className="completion-card">
      <p className="eyebrow">MIGRATION COMPLETE</p><h1>Every image note is processed.</h1>
      <p>{view.completed} translations saved. The JSON file retains the original fields and completion history.</p>
      <p>Removal instructions: <code>image-translation-migration.md</code></p>
      <button className="button button--primary" type="button" disabled={busy} onClick={() => void exit()}>Return home</button>
    </section> : <>
      <section className="word-banner"><div><p className="eyebrow">EXISTING NOTE #{current.noteId}</p><h1>{current.word}</h1></div><div className="word-banner__meta"><span>{view.profileName}</span><span>{draftStatus}</span></div></section>
      <div className="image-migration-grid">
        <aside className="image-migration-context panel">
          <h2>Image context</h2>
          <div className="image-migration-images">{Array.from({ length: current.imageCount }, (_, index) => <MigrationImage key={`${current.noteId}-${index}`} noteId={current.noteId} index={index} />)}</div>
          <h3>Current Polish translation</h3><p className="image-migration-current">{plainText(current.fields.pl_translation) || '(empty)'}</p>
          <p className="muted">Saving replaces this translation on note {current.noteId}.</p>
        </aside>
        <section className="editor-column">
          <section className="panel translations-panel">
            <div className="panel__heading"><h2>Meanings from Diki</h2><span className="counter-badge">{selected} selected</span></div>
            <label className="field-label" htmlFor="migration-lookup">Dictionary lookup</label>
            <div className="suggestion-edit"><input id="migration-lookup" className="text-input" disabled={busy || !draft} value={draft?.lookupWord ?? ''} onChange={(event) => { if (draft) changeDraft({ ...draft, lookupWord: event.target.value }) }} onKeyDown={(event) => { if (event.key === 'Enter' && draft) void run(async () => { await flushDraft(); await lookupNow(draft.lookupWord) }) }} /><button className="button button--secondary" type="button" disabled={busy || !draft?.lookupWord.trim()} onClick={() => void run(async () => { await flushDraft(); await lookupNow(draftRef.current?.lookupWord ?? '') })}>Look up</button></div>
            {draft?.suggestions.length ? <div className="suggestion-list">{draft.suggestions.map((word) => <button type="button" key={word} disabled={busy} onClick={() => void run(async () => { await flushDraft(); await lookupNow(word) })}>{word}</button>)}</div> : null}
            {busy ? <p className="muted" role="status">Working…</p> : null}
            <TranslationEditor key={current.noteId} groups={draft?.groups ?? []} disabled={busy || !draft} emptyText="Try a dictionary suggestion or add a custom translation below." onChange={(groups) => { if (draft) changeDraft({ ...draft, groups, lookedUp: true }) }} />
          </section>
          <section className="panel preview-panel"><h2>New Polish translation</h2>
            {previewError ? <p className="inline-error">{previewError}</p> : <div className="card-preview__translation" dangerouslySetInnerHTML={{ __html: preview || '<span class="empty-preview">Select a translation to preview it.</span>' }} />}
            <div className="image-migration-actions"><button className="button button--primary" type="button" aria-keyshortcuts="Meta+S" title="Save translation & next (⌘S)" disabled={busy || !hasTranslation} onClick={() => void save()}>{busy ? 'Working…' : 'Save translation & next'}</button><button className="button button--secondary" type="button" disabled={busy} onClick={() => void skip()}>Skip for now</button></div>
            <p className="muted">Shortcut: <kbd>⌘S</kbd> to save and open the next note.</p>
          </section>
          <section className="panel image-migration-ai"><button className="button button--secondary" type="button" disabled={busy || !draft?.lookupWord.trim()} onClick={() => void askAI()}>Ask Gemini for translation help</button>{aiText ? <div className="image-migration-ai-answer">{aiText}</div> : null}</section>
        </section>
      </div>
    </>}
    {view ? <p className="image-migration-storage">Progress: <code>{view.progressPath}</code></p> : null}
  </main>
}
