import { useEffect, useRef, useState } from 'react'
import { api } from './api'
import { MigrationAudio, MigrationImage } from './MigrationMedia'
import { TranslationEditor } from './TranslationEditor'
import { ReviewPrefetch } from './reviewPrefetch'
import type { Translation } from './types'

const BASE = '/backend/image-translation-migration'
export type AIReviewKind = 'review' | 'manual' | 'accepted'
type Draft = { lookupWord: string; groups: Translation[][]; suggestions: string[]; lookedUp: boolean }
type QueueItem = { noteId: number; word: string; status: string; batchId: string }
type Summary = { revision: number; aiCounts: Record<string, number>; syncWarning?: string }
type Queue = Summary & { items: QueueItem[] }
type AINote = Summary & {
  noteId: number
  noteToken: string
  profileName: string
  fields: Record<string, string>
  originalFields: Record<string, string>
  imageCount: number
  audioCount: number
  proposalHtml: string
  draft: Draft
  ai: {
    status: string; batchId: string; groups: string[][]; reviewReason?: string; preparationError?: string
    selection: { selectedIds: string[]; visualDescription: string; reason: string; needsReview: boolean }
  }
}
type SaveJob = { id: string; noteId: number; word: string; action: 'accept' | 'manual' | 'flawed'; status: 'queued' | 'running' | 'done' | 'failed' | 'cancelled'; error?: string; completedRevision?: number | null }
type SaveJobs = { jobs: SaveJob[]; pending: number; failed: number }

function text(value: string) {
  return new DOMParser().parseFromString(value.replace(/<br\s*\/?\s*>/gi, '\n'), 'text/html').body.textContent ?? ''
}
function errorText(error: unknown) { return error instanceof Error ? error.message : 'Review request failed' }
function belongsToQueue(status: string, kind: AIReviewKind) {
  return kind === 'review' ? status === 'proposed' : kind === 'manual' ? ['flawed', 'unresolved'].includes(status) : ['accepted', 'corrected'].includes(status)
}

export function AITranslationReview({ initialKind, onExit }: { initialKind: AIReviewKind; onExit: () => void }) {
  const [kind, setKind] = useState(initialKind)
  const [queue, setQueue] = useState<Queue | null>(null)
  const [note, setNote] = useState<AINote | null>(null)
  const [draft, setDraft] = useState<Draft | null>(null)
  const [manual, setManual] = useState(initialKind === 'manual')
  const [busy, setBusy] = useState(true)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [saveStatus, setSaveStatus] = useState('Saved locally')
  const [preview, setPreview] = useState('')
  const [batch, setBatch] = useState('')
  const [reviewReason, setReviewReason] = useState('')
  const [saveJobs, setSaveJobs] = useState<SaveJobs>({ jobs: [], pending: 0, failed: 0 })
  const [images, setImages] = useState<Array<string | undefined>>([])
  const queueRef = useRef<Queue | null>(null)
  const kindRef = useRef(initialKind)
  const jobsRef = useRef<SaveJobs>({ jobs: [], pending: 0, failed: 0 })
  const busyRef = useRef(false)
  const submitting = useRef(false)
  const viewEpoch = useRef(0)
  const submittedNotes = useRef(new Set<number>())
  const displayedImageDigests = useRef<Array<string | undefined>>([])
  const cache = useRef(new ReviewPrefetch<AINote>((id) => api.get<AINote>(`${BASE}/ai/notes/${id}`)))
  const noteRef = useRef<AINote | null>(null)
  const draftRef = useRef<Draft | null>(null)
  const revision = useRef(0)
  const version = useRef(0)
  const saved = useRef(0)
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const serial = useRef<Promise<unknown>>(Promise.resolve())
  const opened = useRef(false)

  function enqueue<T,>(job: () => Promise<T>) {
    const result = serial.current.then(job)
    serial.current = result.catch(() => undefined)
    return result
  }
  function cancelTimer() { if (timer.current) clearTimeout(timer.current); timer.current = undefined }
  function updateJobs(value: SaveJobs) { jobsRef.current = value; setSaveJobs(value) }
  function updateQueue(value: Queue, nextKind = kindRef.current) {
    if (nextKind === kindRef.current && queueRef.current && value.revision < queueRef.current.revision) return
    kindRef.current = nextKind; queueRef.current = value; setQueue(value)
    revision.current = Math.max(revision.current, value.revision)
  }
  function visibleItems(value = queueRef.current, filter = batch, queueKind = kindRef.current) {
    const hidden = new Set(jobsRef.current.jobs.filter((job) => {
      if (['queued', 'running', 'failed'].includes(job.status)) return true
      // A newer POST acknowledgment can report job A done while our last queue
      // snapshot still contains A. Do not resurrect A from that older snapshot.
      // Scope suppression to its source queues so accepted history stays usable.
      const destination = job.action === 'flawed' ? 'manual' : 'accepted'
      return job.status === 'done' && job.completedRevision != null && value != null
        && value.revision < job.completedRevision && queueKind !== destination
    }).map((job) => job.noteId))
    return value?.items.filter((item) => belongsToQueue(item.status, queueKind)
      && (!filter || item.batchId === filter) && !hidden.has(item.noteId)) ?? []
  }
  function adopt(value: AINote) {
    noteRef.current = value; draftRef.current = value.draft; revision.current = Math.max(revision.current, value.revision)
    version.current = 0; saved.current = 0
    setNote(value); setDraft(value.draft); setReviewReason(''); setSaveStatus('Saved locally'); setPreview('')
  }
  async function loadNote(noteId: number, isManual = kindRef.current === 'manual', targetKind = kindRef.current, filter = batch) {
    const epoch = viewEpoch.current
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const value = await cache.current.get(noteId)
      if (epoch !== viewEpoch.current || targetKind !== kindRef.current) return false
      const member = visibleItems(queueRef.current, filter, targetKind).some((item) => item.noteId === noteId)
      if (member && belongsToQueue(value.note.ai.status, targetKind)) {
        adopt(value.note)
        setImages(value.images)
        displayedImageDigests.current = value.imageDigests
        setManual(isManual)
        return true
      }
      // Cached metadata (or the queue itself) can be stale after a background
      // completion. Never adopt an accepted note into the proposal editor.
      cache.current.drop(noteId)
    }
    return false
  }
  async function loadQueue(nextKind: AIReviewKind, filter = batch, preferredId?: number) {
    for (let attempt = 0; attempt < 3; attempt += 1) {
      updateJobs(await api.get<SaveJobs>(`${BASE}/ai/jobs`))
      const value = await api.get<Queue>(`${BASE}/ai/queue?kind=${nextKind}`)
      updateQueue(value, nextKind); setKind(nextKind)
      const candidates = visibleItems(queueRef.current, filter, nextKind)
      const item = candidates.find((item) => item.noteId === preferredId) ?? candidates[0]
      if (!item) { setNote(null); noteRef.current = null; setDraft(null); draftRef.current = null; version.current = 0; saved.current = 0; return }
      if (await loadNote(item.noteId, nextKind === 'manual', nextKind, filter)) return
    }
    throw new Error('The review queue changed while loading. Reload review to continue.')
  }
  async function persist(noteId: number, value: Draft, editVersion: number) {
    if (noteRef.current?.noteId !== noteId) return
    setSaveStatus('Saving draft…')
    const result = await api.patch<Summary>(`${BASE}/ai/draft`, { noteId, revision: revision.current, noteToken: noteRef.current.noteToken, draft: value })
    if (noteRef.current?.noteId !== noteId) return
    revision.current = result.revision; saved.current = editVersion
    noteRef.current = { ...noteRef.current, draft: value, revision: result.revision }
    cache.current.update(noteRef.current)
    setSaveStatus(version.current === editVersion ? 'Saved locally' : 'Unsaved edits…')
  }
  async function flush() {
    if (noteRef.current && draftRef.current && saved.current !== version.current) {
      await persist(noteRef.current.noteId, draftRef.current, version.current)
    }
  }
  function change(value: Draft) {
    if (!noteRef.current) return
    draftRef.current = value; version.current += 1
    setDraft(value); setSaveStatus('Unsaved edits…'); cancelTimer()
    const id = noteRef.current.noteId, editVersion = version.current
    timer.current = setTimeout(() => { void enqueue(() => persist(id, value, editVersion)).catch((error) => { if (!submittedNotes.current.has(id)) { setError(errorText(error)); setSaveStatus('Draft not saved — retry before exiting') } }) }, 550)
  }
  async function run(job: () => Promise<void>) {
    cancelTimer(); viewEpoch.current += 1; busyRef.current = true; setBusy(true); setError('')
    try { await enqueue(job) } catch (error) { setError(errorText(error)) } finally { busyRef.current = false; setBusy(false) }
  }
  useEffect(() => {
    if (!opened.current) { opened.current = true; void run(() => loadQueue(initialKind, '')) }
    return () => { cancelTimer(); cache.current.clear() }
  }, [])
  useEffect(() => {
    let active = true, polling = false
    async function poll() {
      if (polling || busyRef.current) return
      polling = true
      const epoch = viewEpoch.current
      try {
        // Read jobs first, then progress: a done job's field/progress writes are
        // already visible before it can disappear from the pending indicator.
        const jobs = await api.get<SaveJobs>(`${BASE}/ai/jobs`)
        const value = await api.get<Queue>(`${BASE}/ai/queue?kind=${kind}`)
        if (active && !busyRef.current && epoch === viewEpoch.current) {
          updateJobs(jobs); updateQueue(value, kind)
          const current = noteRef.current
          if (current && !visibleItems().some((item) => item.noteId === current.noteId)) {
            if (version.current !== saved.current) {
              setError('This note changed outside the current review. Your correction is kept; reload to reconcile it.')
            } else {
              await run(() => loadQueue(kind))
            }
          }
        }
      } catch (error) { if (active) setError(errorText(error)) }
      finally { polling = false }
    }
    const interval = setInterval(() => void poll(), 700)
    return () => { active = false; clearInterval(interval) }
  }, [kind, batch])
  useEffect(() => {
    const list = visibleItems()
    const index = list.findIndex((item) => item.noteId === note?.noteId)
    list.slice(index + 1, index + 3).forEach((item) => cache.current.prefetch(item.noteId))
  }, [queue, saveJobs, batch, note?.noteId])
  useEffect(() => {
    function warn(event: BeforeUnloadEvent) { if (version.current !== saved.current) { event.preventDefault(); event.returnValue = '' } }
    window.addEventListener('beforeunload', warn)
    return () => window.removeEventListener('beforeunload', warn)
  }, [])
  useEffect(() => {
    if (!manual || !draft) return
    let active = true
    const timeout = setTimeout(() => { void api.post<{ translationHtml: string }>(`${BASE}/preview`, draft).then((value) => { if (active) setPreview(value.translationHtml) }).catch((error) => { if (active) setError(errorText(error)) }) }, 180)
    return () => { active = false; clearTimeout(timeout) }
  }, [manual, draft])

  async function decide(action: 'accept' | 'manual' | 'flawed') {
    if (submitting.current || busyRef.current || !noteRef.current) return
    const value = noteRef.current
    const digests = displayedImageDigests.current.filter((hash): hash is string => Boolean(hash))
    // Freeze the clicked note/draft before changing the screen. No queued job
    // may refer to whichever note happens to be displayed when it later runs.
    const decision = { id: crypto.randomUUID(), noteId: value.noteId, profileName: value.profileName,
      noteToken: value.noteToken, action, expectedTranslation: value.fields.pl_translation,
      expectedImage: value.fields.image,
      ...(digests.length === value.imageCount ? { imageDigests: digests } : {}),
      ...(action === 'manual' ? { draft: JSON.parse(JSON.stringify(draftRef.current)) } : {}),
      reason: reviewReason.trim() || 'Marked flawed during human review' }
    cancelTimer(); viewEpoch.current += 1; submitting.current = true; busyRef.current = true; setBusy(true); setError('')
    try {
      let result: SaveJobs
      try { result = await api.post<SaveJobs>(`${BASE}/ai/jobs`, decision) }
      catch (failure) {
        // A lost enqueue acknowledgement is not a lost decision. The stable ID
        // lets us locate the already-durable job without submitting it twice.
        result = await api.get<SaveJobs>(`${BASE}/ai/jobs`)
        if (!result.jobs.some((job) => job.id === decision.id)) throw failure
      }
      updateJobs(result); submittedNotes.current.add(value.noteId); cache.current.drop(value.noteId)
      if (queueRef.current) updateQueue({ ...queueRef.current, items: queueRef.current.items.filter((item) => item.noteId !== value.noteId) })
      setNotice(`Decision for “${value.fields.en_word}” queued. Evaluation is recorded only after saving succeeds.`)
      const next = visibleItems()[0]
      noteRef.current = null; draftRef.current = null; version.current = 0; saved.current = 0
      setNote(null); setDraft(null)
      if (next && !await loadNote(next.noteId, kind === 'manual')) await loadQueue(kind)
    } catch (error) { setError(errorText(error)) }
    finally { submitting.current = false; busyRef.current = false; setBusy(false) }
  }

  async function retryFailed() {
    await run(async () => { await flush(); updateJobs(await api.post<SaveJobs>(`${BASE}/ai/jobs/retry`)) })
  }
  async function reviewFailed(job: SaveJob) {
    await run(async () => {
      await flush()
      updateJobs(await api.post<SaveJobs>(`${BASE}/ai/jobs/dismiss`, { id: job.id }))
      submittedNotes.current.delete(job.noteId); cache.current.drop(job.noteId)
      const fresh = await api.get<AINote>(`${BASE}/ai/notes/${job.noteId}`)
      const targetKind: AIReviewKind = belongsToQueue(fresh.ai.status, 'accepted') ? 'accepted'
        : belongsToQueue(fresh.ai.status, 'manual') ? 'manual' : 'review'
      setBatch('')
      await loadQueue(targetKind, '', job.noteId)
      if (noteRef.current?.noteId === job.noteId && targetKind !== 'accepted') setManual(job.action === 'manual' || targetKind === 'manual')
    })
  }
  async function lookup(word: string) {
    await run(async () => {
      await flush()
      if (!noteRef.current) return
      const id = noteRef.current.noteId
      await api.post<AINote>(`${BASE}/ai/lookup`, { noteId: id, revision: revision.current, noteToken: noteRef.current.noteToken, word })
      cache.current.drop(id)
      if (!await loadNote(id, true)) await loadQueue(kind)
    })
  }
  async function reload() {
    await run(async () => {
      const id = noteRef.current?.noteId
      const unsaved = version.current !== saved.current ? draftRef.current : null
      if (id) {
        cache.current.drop(id)
        const loaded = await loadNote(id, manual)
        const status = noteRef.current?.ai.status ?? ''
        if (!loaded) await loadQueue(kind)
        else if (unsaved && !['accepted', 'corrected'].includes(status)) { change(unsaved); cancelTimer(); await flush() }
      } else await loadQueue(kind)
    })
  }
  const canEdit = note && !['accepted', 'corrected'].includes(note.ai.status)
  const hasTranslation = draft?.groups.some((group) => group.some((item) => item.selected && !item.isBreak && item.value.trim() && item.value.trim() !== '<br>'))
  useEffect(() => {
    function shortcut(event: KeyboardEvent) {
      if (!event.metaKey || event.ctrlKey || event.altKey || event.shiftKey || event.key.toLowerCase() !== 's') return
      event.preventDefault()
      if (!event.repeat && !busy && ((manual && canEdit && hasTranslation) || (!manual && note?.ai.status === 'proposed'))) void decide(manual ? 'manual' : 'accept')
    }
    window.addEventListener('keydown', shortcut)
    return () => window.removeEventListener('keydown', shortcut)
  })
  const items = visibleItems()

  return <main className="workspace-shell image-migration ai-review">
    <header className="topbar workspace-topbar"><div className="brand"><span className="brand__mark">AF</span><span>Assistant translation review</span></div><button className="button button--secondary" disabled={busy} onClick={() => void run(async () => { await flush(); onExit() })}>Save draft & exit</button></header>
    <section className="ai-save-status" aria-live="polite"><span>{saveJobs.pending ? `${saveJobs.pending} save${saveJobs.pending === 1 ? '' : 's'} pending in background` : 'All queued saves finished'}</span>{saveJobs.failed ? <><strong>{saveJobs.failed} save{saveJobs.failed === 1 ? '' : 's'} failed — not marked evaluated</strong><button className="button button--secondary" disabled={busy} onClick={() => void retryFailed()}>Retry failed saves</button></> : null}</section>
    {saveJobs.jobs.filter((job) => job.status === 'failed').map((job) => <div className="inline-error" key={job.id}><b>{job.word}:</b> {job.error} <button className="tiny-button" disabled={busy} onClick={() => void reviewFailed(job)}>Review again</button></div>)}
    <section className="panel ai-review-navigation">
      <div className="image-migration-actions">{(['review', 'manual', 'accepted'] as const).map((value) => <button className={`button ${kind === value ? 'button--primary' : 'button--secondary'}`} key={value} disabled={busy} onClick={() => void run(async () => { await flush(); await loadQueue(value) })}>{value === 'review' ? `Review AI (${queue?.aiCounts.proposed ?? 0})` : value === 'manual' ? `Fix flawed / unresolved (${(queue?.aiCounts.flawed ?? 0) + (queue?.aiCounts.unresolved ?? 0)})` : `Accepted history (${(queue?.aiCounts.accepted ?? 0) + (queue?.aiCounts.corrected ?? 0)})`}</button>)}</div>
      <label>Batch<select className="select-input" disabled={busy} value={batch} onChange={(event) => { const value = event.target.value; void run(async () => { await flush(); setBatch(value); await loadQueue(kind, value) }) }}><option value="">All batches</option>{Array.from(new Set(queue?.items.map((item) => item.batchId))).map((value) => <option key={value}>{value}</option>)}</select></label>
      <label>Note ({items.length})<select className="select-input" disabled={busy || !items.length} value={note?.noteId ?? ''} onChange={(event) => { const id = Number(event.target.value); void run(async () => { await flush(); if (!await loadNote(id)) await loadQueue(kind) }) }}><option value="" disabled>Choose a note</option>{items.map((item) => <option key={item.noteId} value={item.noteId}>{item.word} · {item.status}</option>)}</select></label>
    </section>
    {error ? <div className="notice notice--error" role="alert"><p>{error}</p><button className="button button--secondary" disabled={busy} onClick={() => void reload()}>Reload review</button></div> : null}
    {notice ? <p className="notice notice--success" role="status">{notice}</p> : null}
    {!note ? <section className="panel preview-panel"><h1>{busy ? 'Opening review…' : saveJobs.pending ? 'Saving final reviews…' : saveJobs.failed ? 'Failed saves need review' : 'No notes in this review queue'}</h1><p>Decisions are saved in the background. Only verified saves count as evaluated; failed saves remain pending for review.</p></section> : <>
      <section className="word-banner"><div><p className="eyebrow">NOTE #{note.noteId} · {note.ai.batchId} · {note.ai.status}</p><h1>{note.fields.en_word}</h1></div><span>{manual ? saveStatus : 'Review before writing to Anki'}</span></section>
      <div className="image-migration-grid"><aside className="panel image-migration-context"><h2>Full note</h2><div className="image-migration-images">{Array.from({ length: note.imageCount }, (_, index) => <MigrationImage key={`${note.noteId}-${index}`} noteId={note.noteId} index={index} src={images[index]} />)}</div>
        <h3>English audio</h3>{note.audioCount ? Array.from({ length: note.audioCount }, (_, index) => <MigrationAudio key={`${note.noteId}-${index}`} noteId={note.noteId} index={index} />) : <p className="muted">No audio (allowed)</p>}
        <h3>Current Polish translation</h3><p className="image-migration-current">{text(note.fields.pl_translation) || '(empty)'}</p><h3>Original Polish translation</h3><p>{text(note.originalFields.pl_translation) || '(empty)'}</p>
        <details><summary>All four field values</summary>{Object.entries(note.fields).map(([name, value]) => <div key={name}><h4>{name}</h4><pre>{value || '(empty)'}</pre></div>)}</details>
      </aside><section className="editor-column">
        <section className="panel preview-panel"><h2>Assistant’s selection</h2><div className="card-preview__translation" dangerouslySetInnerHTML={{ __html: note.proposalHtml || '<i>No selection — manual decision needed.</i>' }} /><h3>What the image shows</h3><p>{note.ai.selection.visualDescription}</p><h3>Why this meaning</h3><p>{note.ai.selection.reason}</p>{note.ai.reviewReason ? <p className="inline-error">Review feedback: {note.ai.reviewReason}</p> : null}{note.ai.preparationError ? <p className="inline-error">Dictionary preparation: {note.ai.preparationError}</p> : null}</section>
        <section className="panel translations-panel"><h2>All Diki alternatives used by the assistant</h2>{note.ai.groups.length ? note.ai.groups.map((group, gi) => <div className="ai-candidate-group" key={gi}><p className="eyebrow">Sense {gi + 1}</p>{group.map((value, ti) => <span className={note.ai.selection.selectedIds.includes(`${gi}:${ti}`) ? 'ai-candidate ai-candidate-selected' : 'ai-candidate'} key={ti}>{note.ai.selection.selectedIds.includes(`${gi}:${ti}`) ? '✓ ' : ''}{value}</span>)}</div>) : <p>No exact-match Diki candidates were available.</p>}</section>
        {manual && canEdit ? <section className="panel translations-panel"><h2>Manual correction</h2><div className="suggestion-edit"><input aria-label="Manual dictionary lookup" className="text-input" disabled={busy} value={draft?.lookupWord ?? ''} onChange={(event) => { if (draft) change({ ...draft, lookupWord: event.target.value }) }} /><button className="button button--secondary" disabled={busy || !draft?.lookupWord.trim()} onClick={() => void lookup(draft?.lookupWord ?? '')}>Look up</button></div><div className="suggestion-list">{draft?.suggestions.map((word) => <button key={word} disabled={busy} onClick={() => void lookup(word)}>{word}</button>)}</div><TranslationEditor key={note.noteId} disabled={busy} groups={draft?.groups ?? []} emptyText="Look up another spelling or enter a custom translation." onChange={(groups) => { if (draft) change({ ...draft, groups, lookedUp: true }) }} /><h3>Correction preview</h3><div className="card-preview__translation" dangerouslySetInnerHTML={{ __html: preview || '<i>Select or enter a translation.</i>' }} /></section> : null}
        <section className="panel preview-panel"><label className="field-label">Feedback (optional)<input className="text-input" disabled={busy} value={reviewReason} onChange={(event) => setReviewReason(event.target.value)} /></label><div className="image-migration-actions">
          {!manual && note.ai.status === 'proposed' ? <button className="button button--primary" aria-keyshortcuts="Meta+S" disabled={busy} onClick={() => void decide('accept')}>Accept & next</button> : null}
          {manual && canEdit ? <button className="button button--primary" aria-keyshortcuts="Meta+S" disabled={busy || !hasTranslation} onClick={() => void decide('manual')}>Save correction & next</button> : null}
          <button className="button button--secondary" disabled={busy} onClick={() => void decide('flawed')}>Mark flawed & next</button>
          {canEdit && !manual ? <button className="button button--secondary" disabled={busy} onClick={() => setManual(true)}>Correct manually now</button> : null}
          {manual && kind === 'review' ? <button className="text-button" disabled={busy} onClick={() => void run(async () => { await flush(); setManual(false) })}>Back to proposal</button> : null}
        </div><p className="muted">⌘S accepts the proposal or saves the manual correction. Mark flawed adds the Anki tag AI_PL_FLAWED.</p></section>
      </section></div>
    </>}
  </main>
}
