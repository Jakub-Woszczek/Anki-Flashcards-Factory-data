type ImageNote = { noteId: number; imageCount: number }
type CachedNote<T> = { note: T; images: Array<string | undefined>; imageDigests: Array<string | undefined> }
type Entry<T> = { promise: Promise<CachedNote<T>>; urls: string[]; controller: AbortController }

// Keep decoded blob URLs rather than relying on HTTP caching of Anki's no-store
// media endpoint. A bounded cache also prevents long review sessions leaking RAM.
export class ReviewPrefetch<T extends ImageNote> {
  private entries = new Map<number, Entry<T>>()

  constructor(private load: (id: number) => Promise<T>, private limit = 6) {}

  get(id: number): Promise<CachedNote<T>> {
    const existing = this.entries.get(id)
    if (existing) {
      this.entries.delete(id)
      this.entries.set(id, existing)
      return existing.promise
    }
    const entry: Entry<T> = { promise: Promise.resolve(null as never), urls: [], controller: new AbortController() }
    entry.promise = this.load(id).then(async (note) => {
      if (this.entries.get(id) !== entry) throw new Error('Prefetch expired')
      const imageDigests: Array<string | undefined> = []
      const images = await Promise.all(Array.from({ length: note.imageCount }, async (_, index) => {
        let url: string | undefined
        try {
          const response = await fetch(`/backend/image-translation-migration/images/${id}/${index}`, { signal: entry.controller.signal })
          if (!response.ok) return undefined
          const blob = await response.blob()
          const digest = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer())
          imageDigests[index] = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('')
          url = URL.createObjectURL(blob)
          entry.urls.push(url)
          const image = new Image()
          image.src = url
          await image.decode()
          return url
        } catch {
          if (url) { URL.revokeObjectURL(url); entry.urls = entry.urls.filter((value) => value !== url) }
          return undefined // The visible image component can retry the source.
        }
      }))
      if (this.entries.get(id) !== entry) { entry.urls.forEach(URL.revokeObjectURL); throw new Error('Prefetch expired') }
      return { note, images, imageDigests }
    }).catch((error) => {
      if (this.entries.get(id) === entry) this.drop(id)
      throw error
    })
    this.entries.set(id, entry)
    while (this.entries.size > this.limit) this.drop(this.entries.keys().next().value!)
    return entry.promise
  }

  prefetch(id: number) { void this.get(id).catch(() => undefined) }

  update(note: T) {
    const entry = this.entries.get(note.noteId)
    if (entry) entry.promise = entry.promise.then((value) => ({ ...value, note }))
  }

  drop(id: number) {
    const entry = this.entries.get(id)
    this.entries.delete(id)
    if (entry) { entry.controller.abort(); entry.urls.forEach(URL.revokeObjectURL) }
  }

  clear() { for (const id of this.entries.keys()) this.drop(id) }
}
