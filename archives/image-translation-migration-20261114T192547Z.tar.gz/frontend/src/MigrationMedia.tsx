import { useState } from 'react'

const BASE = '/backend/image-translation-migration'

export function MigrationImage({ noteId, index, src }: { noteId: number; index: number; src?: string }) {
  const [failed, setFailed] = useState(false)
  return failed
    ? <p className="inline-error">Image {index + 1} could not be loaded from Anki. Check the note’s media.</p>
    : <img src={src ?? `${BASE}/images/${noteId}/${index}`} alt={`Image ${index + 1} for the current English word`} onError={() => setFailed(true)} />
}

export function MigrationAudio({ noteId, index }: { noteId: number; index: number }) {
  const [failed, setFailed] = useState(false)
  return failed
    ? <p className="muted">Recording {index + 1} is missing or unsupported.</p>
    : <audio controls preload="none" aria-label={`English recording ${index + 1}`} src={`${BASE}/audio/${noteId}/${index}`} onError={() => setFailed(true)} />
}
